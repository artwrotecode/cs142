package Footballers;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.Normalizer;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.filechooser.FileNameExtensionFilter;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        FootballersGUI.java
 * Description  A class representing the GUI used in a maintaining a footballers 
 *              database.
 * Project      Project 1 - Famous Football Players
 * Platform     jdk 25.0.1; NetBeans IDE 28; Mac OS X version 15.6.1
 * Course       CS 142--Project1, Winter 2025, Edmonds College
 * Hours        5 hours
 * @author	<i>Arthur Rahman</i>
 * @version 	%1% 
 * Date         1/8/2026
 * History Log  
 * @see     	javax.swing.JFrame
 * @see         java.awt.Toolkit
 * @see         java.util.ArrayList
 * @see         java.text.DecimalFormat
 * @see         Player
 * @see         AddPlayer
 * @see         EditPlayer
 * @see         About
 * @see         Detail
 * @see         Splash
 *</pre>
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class FootballersGUI extends javax.swing.JFrame
{   
    // class instance ArrayList of Player objects
    private ArrayList<Player> players = new ArrayList<Player>();
    // external file name for players
    private String fileName = "src/Data/Players1.txt";
    // private final String fileNameXML = "src/USACities/AltCities.xml";
    DecimalFormat number = new DecimalFormat("#,##0");
    DecimalFormat dollars = new DecimalFormat("$#,##0.00");
     /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Constructor  FootballersGUI()-default constructor
     * Description  Create an instance of the GUI form, set the default 
     *              addJButton as default JButton, set icon image, center form,
     *              read players from an external Players.txt file, and display
     *              names of players in a Jlist sorted alphabetically initially.
     * @author      <i>Arthur Rahman</i>
     * Date         1/8/2026
     * History Log  
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public FootballersGUI()
    {
        initComponents();
        this.getRootPane().setDefaultButton(addJButton);
        this.setIconImage(Toolkit.getDefaultToolkit().
                getImage("src/Images/stock_soccer.jpg"));
        //centers the form at start.
        setLocationRelativeTo(null);
        // Read fromm an external file Players.txt and populate an ArrayList
        readFromFile(fileName);
        // Show the player names in the JList
        displayPlayers();
        int index = playersJList.getSelectedIndex();
        if (index >= 0)
                showPlayerData(playersJList.getSelectedIndex());
      
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       readFromFile
     * Description  Reads Players from a text file that is comma delimited and
     *              creates an instance of the Player class with the data read.
     * @param       file String
     * @see         Player
     * @see         java.util.StringTokenizer
     * @see         java.io.FileNotFoundException
     * @see         java.util.Scanner
     * @see         javax.swing.filechooser.FileNameExtensionFilter
     * @see         java.io.File
     * Date         01/14/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public void readFromFile(String file) {
        players.clear(); // clear the ArrayList
        try {
            Scanner input = new Scanner(new File(file));
            String line = "";
            Player footballer = null;
            StringTokenizer token = null;
            while (input.hasNextLine()) {
                line = input.nextLine();
                footballer = new Player();
                token = new StringTokenizer(line, ",");
                while (token.hasMoreElements()) {
                    footballer.setName(token.nextToken());
                    footballer.setTeam(token.nextToken());
                    footballer.setBirth(token.nextToken());
                    footballer.setSalary(Double.parseDouble(token.nextToken()));
                    footballer.setCountry(token.nextToken());
                    footballer.setGames(Integer.parseInt(token.nextToken()));
                    footballer.setGoals(Integer.parseInt(token.nextToken()));
                    if (token.hasMoreTokens()) {
                        footballer.setUrl(token.nextToken());
                    } else {
                        footballer.setUrl(null); // old file, no URL
                    }
                }
                // add city to arraylist
                players.add(footballer);
            }
            input.close();
        }
        catch(FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, file + " does not exist",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
            // Bring up JFileChooser to select file in curent directory
            JFileChooser chooser = new JFileChooser("src/Footballers");
            // Filter only txt files
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Txt Files", "txt");
            chooser.setFileFilter(filter);
            int choice = chooser.showOpenDialog(null);
            if (choice == JFileChooser.APPROVE_OPTION) {
                File chosenFile = chooser.getSelectedFile();
                file = "src/Footballers/" + chosenFile.getName();
                System.out.println("file = " + file);
                readFromFile(file);
            }
            else {
                JOptionPane.showMessageDialog(null, "Unable to read file",
                        "File Input Error", JOptionPane.WARNING_MESSAGE);
            }
        }
        catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       displayPlayers
     * Description  Displays players in JList sorted by goals using the
     *              insertionSort algorithm or by player name using the 
     *              selectionSort algorithm.
     * @see         #insertionSort
     * @see         #selectionSort
     * Date         1/14/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void displayPlayers() {
        int location = playersJList.getSelectedIndex();
        String[] playersList = new String[players.size()];
        if (goalsJRadioButtonMenuItem.isSelected()) {
            selectionSort(players);
            for (int index = 0; index < players.size(); index++) {
                playersList[index] = players.get(index).getName() + ", "
                        + players.get(index).getGoals() + " goals";
            }
        }
        else {
            insertionSort(players);

            for(int index = 0; index < players.size(); index++) {
                playersList[index] = players.get(index).getName();
            }

        }
        playersJList.setListData(playersList);
        if (location < 0)
            playersJList.setSelectedIndex(0);
        else
            playersJList.setSelectedIndex(location);
    }

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       showPlayerData()
     * Description  Displays information about selected player
     * @param       index int
     * Date         1/14/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void showPlayerData(int index) {
        if (index >= 0 && index < players.size()) {
            nameJTextField.setText(players.get(index).getName());
            teamJTextField.setText(players.get(index).getTeam());
            birthJTextField.setText(players.get(index).getBirth());
            salaryJTextField.setText(dollars.format(players.get(index).getSalary()));
            countryJTextField.setText(players.get(index).getCountry());
            gamesJTextField.setText(number.format(players.get(index).getGames()));
            goalsJTextField.setText(number.format(players.get(index).getGoals()));
            websiteJTextField.setText(players.get(index).getUrl());
        }
    }


    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       insertionSort
     * Description  Sorts ArrayList players in ascending order by name. Uses 
     *              the insertion sort algorithm which inserts player at correct 
     *              position and shuffles everyone else below that position.
     * @param       players ArrayList
     * Date         1/14/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
      private void insertionSort(ArrayList<Player> players) {
          int i, j;
          for(i = 0; i < players.size(); i++) {
              Player temp = players.get(i);
              j = i - 1;
              while (j >= 0 && players.get(j).getName().
                      compareToIgnoreCase(temp.getName()) > 0) {
                  players.set(j + 1, players.get(j));
                  j--;
              }
              players.set(j + 1, temp);
          }
    }

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       selectionSort
     * Description  Sorts ArrayList players in descending order by goals scored. 
     *              Calls findsMaximum to find player with maximum goals in 
     *              each pass and swap to exchange players when necessary.
     * @param       players ArrayList
     * Date         1/14/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
        private void selectionSort(ArrayList<Player> players) {
            int max = 0;
            for (int i = 0; i < players.size(); i++) {
                max = findMaximum(players, i);
                Player temp = players.get(i);
                players.set(i, players.get(max));
                players.set(max, temp);
            }
    }

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       findMaximum
     * Description  Called by selectionSort to find the index of the member 
     *              with the maximum goals from a given index to the end 
     *              of the ArrayList.
     * @param       players ArrayList 
     * @param       i int index from which to search for the max greater than or equal to 0  
     * @return      position int of index  where maximum is located int
     * Date         1/14/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
       private int findMaximum(ArrayList<Player> players, int i) {
           int j, max = i;
           for (j = i + 1; j < players.size(); j++) {
               if (players.get(j).getGoals() > 
                       players.get(max).getGoals())
                   max = j;
           }
           return max;
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       playerExists
     * Description  Determine if player passed in parameter exits
     * Date         01/26/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       Player newPlayer
     * @return      true or false boolean
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private boolean playerExists(Player newPlayer)
    {
	boolean thereIsOne = false;
	for(int index = 0; index < players.size() && !thereIsOne; index++)
	{
		if (players.get(index).equals(newPlayer))
			thereIsOne = true;
	}
	return thereIsOne;        
    }       
    
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menubuttonGroup = new javax.swing.ButtonGroup();
        titleJPanel = new javax.swing.JPanel();
        logoJLabel = new javax.swing.JLabel();
        titleJLabel = new javax.swing.JLabel();
        listJPanel = new javax.swing.JPanel();
        llistJScrollPane = new javax.swing.JScrollPane();
        playersJList = new javax.swing.JList();
        displayJPanel = new javax.swing.JPanel();
        nameJLabel = new javax.swing.JLabel();
        nameJTextField = new javax.swing.JTextField();
        teamJLabel = new javax.swing.JLabel();
        teamJTextField = new javax.swing.JTextField();
        birthJLabel = new javax.swing.JLabel();
        birthJTextField = new javax.swing.JTextField();
        salaryJLabel = new javax.swing.JLabel();
        salaryJTextField = new javax.swing.JTextField();
        countryJLabel = new javax.swing.JLabel();
        countryJTextField = new javax.swing.JTextField();
        gamesJLabel = new javax.swing.JLabel();
        gamesJTextField = new javax.swing.JTextField();
        goalsJLabel = new javax.swing.JLabel();
        goalsJTextField = new javax.swing.JTextField();
        websiteJLabel = new javax.swing.JLabel();
        websiteJTextField = new javax.swing.JTextField();
        controlPanel = new javax.swing.JPanel();
        addJButton = new javax.swing.JButton();
        editJButton = new javax.swing.JButton();
        deleteJButton = new javax.swing.JButton();
        printJButton = new javax.swing.JButton();
        exitJButton = new javax.swing.JButton();
        citiesJMenuBar = new javax.swing.JMenuBar();
        fileJMenu = new javax.swing.JMenu();
        newJMenuItem = new javax.swing.JMenuItem();
        printJMenuItem = new javax.swing.JMenuItem();
        printFormJMenuItem = new javax.swing.JMenuItem();
        saveJMenuItem = new javax.swing.JMenuItem();
        fileJSeparator = new javax.swing.JPopupMenu.Separator();
        exitJMenuItem = new javax.swing.JMenuItem();
        sortJMenu = new javax.swing.JMenu();
        nameJRadioButtonMenuItem = new javax.swing.JRadioButtonMenuItem();
        goalsJRadioButtonMenuItem = new javax.swing.JRadioButtonMenuItem();
        actionJMenu = new javax.swing.JMenu();
        addJMenuItem = new javax.swing.JMenuItem();
        deleteJMenuItem = new javax.swing.JMenuItem();
        editJMenuItem = new javax.swing.JMenuItem();
        searchJMenuItem = new javax.swing.JMenuItem();
        detailsJMenuItem = new javax.swing.JMenuItem();
        helpJMenu = new javax.swing.JMenu();
        aboutJMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Famous Football Players");
        setResizable(false);
        getContentPane().setLayout(new java.awt.BorderLayout(2, 2));

        logoJLabel.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        logoJLabel.setForeground(new java.awt.Color(51, 0, 0));
        logoJLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/stock_soccer.jpg"))); // NOI18N

        titleJLabel.setFont(new java.awt.Font("Tempus Sans ITC", 2, 24)); // NOI18N
        titleJLabel.setForeground(new java.awt.Color(0, 153, 51));
        titleJLabel.setText("Famous Football Players");

        javax.swing.GroupLayout titleJPanelLayout = new javax.swing.GroupLayout(titleJPanel);
        titleJPanel.setLayout(titleJPanelLayout);
        titleJPanelLayout.setHorizontalGroup(
            titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titleJPanelLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(logoJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(titleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        titleJPanelLayout.setVerticalGroup(
            titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titleJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(titleJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(titleJPanel, java.awt.BorderLayout.NORTH);

        playersJList.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        playersJList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                playersJListValueChanged(evt);
            }
        });
        llistJScrollPane.setViewportView(playersJList);

        javax.swing.GroupLayout listJPanelLayout = new javax.swing.GroupLayout(listJPanel);
        listJPanel.setLayout(listJPanelLayout);
        listJPanelLayout.setHorizontalGroup(
            listJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, listJPanelLayout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(llistJScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        listJPanelLayout.setVerticalGroup(
            listJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, listJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(llistJScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE))
        );

        getContentPane().add(listJPanel, java.awt.BorderLayout.WEST);

        displayJPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5));
        displayJPanel.setPreferredSize(new java.awt.Dimension(340, 191));
        displayJPanel.setLayout(new java.awt.GridLayout(8, 2, 5, 5));

        nameJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nameJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        nameJLabel.setText("Name of player: ");
        displayJPanel.add(nameJLabel);

        nameJTextField.setEditable(false);
        nameJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        nameJTextField.setToolTipText("Player's name");
        displayJPanel.add(nameJTextField);

        teamJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        teamJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        teamJLabel.setText("Team: ");
        displayJPanel.add(teamJLabel);

        teamJTextField.setEditable(false);
        teamJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        teamJTextField.setToolTipText("Player's club");
        displayJPanel.add(teamJTextField);

        birthJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        birthJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        birthJLabel.setText("Birth date: ");
        displayJPanel.add(birthJLabel);

        birthJTextField.setEditable(false);
        birthJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        birthJTextField.setToolTipText("Birthday of Player , in day month year format");
        displayJPanel.add(birthJTextField);

        salaryJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        salaryJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        salaryJLabel.setText("Salary: ");
        displayJPanel.add(salaryJLabel);

        salaryJTextField.setEditable(false);
        salaryJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        salaryJTextField.setToolTipText("Yearly salary in USD");
        displayJPanel.add(salaryJTextField);

        countryJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        countryJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        countryJLabel.setText("Representing country: ");
        displayJPanel.add(countryJLabel);

        countryJTextField.setEditable(false);
        countryJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        countryJTextField.setToolTipText("Country represented in international");
        displayJPanel.add(countryJTextField);

        gamesJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        gamesJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        gamesJLabel.setText("Games played: ");
        displayJPanel.add(gamesJLabel);

        gamesJTextField.setEditable(false);
        gamesJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        gamesJTextField.setToolTipText("Total games played");
        displayJPanel.add(gamesJTextField);

        goalsJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        goalsJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        goalsJLabel.setText("Goals scored: ");
        displayJPanel.add(goalsJLabel);

        goalsJTextField.setEditable(false);
        goalsJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        goalsJTextField.setToolTipText("Total goals scored");
        displayJPanel.add(goalsJTextField);

        websiteJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        websiteJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        websiteJLabel.setText("Website URL: ");
        displayJPanel.add(websiteJLabel);

        websiteJTextField.setEditable(false);
        websiteJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        websiteJTextField.setToolTipText("Player website");
        displayJPanel.add(websiteJTextField);

        getContentPane().add(displayJPanel, java.awt.BorderLayout.EAST);

        controlPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        controlPanel.setMinimumSize(new java.awt.Dimension(299, 45));
        controlPanel.setLayout(new java.awt.GridLayout(1, 5, 5, 5));

        addJButton.setBackground(new java.awt.Color(0, 153, 51));
        addJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        addJButton.setMnemonic('A');
        addJButton.setText("Add");
        addJButton.setToolTipText("Add new player");
        addJButton.setMinimumSize(new java.awt.Dimension(57, 45));
        addJButton.setPreferredSize(new java.awt.Dimension(57, 35));
        addJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(addJButton);

        editJButton.setBackground(new java.awt.Color(0, 153, 51));
        editJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        editJButton.setMnemonic('E');
        editJButton.setText("Edit");
        editJButton.setToolTipText("Edit player. Press Enter in any of the JTextFields to confirm changes...");
        editJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(editJButton);

        deleteJButton.setBackground(new java.awt.Color(0, 153, 51));
        deleteJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        deleteJButton.setMnemonic('D');
        deleteJButton.setText("Delete");
        deleteJButton.setToolTipText("Delete player");
        deleteJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(deleteJButton);

        printJButton.setBackground(new java.awt.Color(0, 153, 51));
        printJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printJButton.setMnemonic('P');
        printJButton.setText("Print");
        printJButton.setToolTipText("Print individual player data");
        printJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(printJButton);

        exitJButton.setBackground(new java.awt.Color(0, 153, 51));
        exitJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitJButton.setMnemonic('x');
        exitJButton.setText("Exit");
        exitJButton.setToolTipText("Exit application");
        exitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(exitJButton);

        getContentPane().add(controlPanel, java.awt.BorderLayout.SOUTH);

        fileJMenu.setMnemonic('F');
        fileJMenu.setText("File");
        fileJMenu.setToolTipText("File options");

        newJMenuItem.setMnemonic('N');
        newJMenuItem.setText("New");
        newJMenuItem.setToolTipText("Load new Player database");
        newJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(newJMenuItem);

        printJMenuItem.setMnemonic('P');
        printJMenuItem.setText("Print");
        printJMenuItem.setToolTipText("Print individual player details");
        printJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printJMenuItem);

        printFormJMenuItem.setMnemonic('t');
        printFormJMenuItem.setText("Print Form");
        printFormJMenuItem.setToolTipText("Print form as GUI");
        printFormJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printFormJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printFormJMenuItem);

        saveJMenuItem.setMnemonic('S');
        saveJMenuItem.setText("Save");
        saveJMenuItem.setToolTipText("Save data of player to an external text file");
        saveJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(saveJMenuItem);
        fileJMenu.add(fileJSeparator);

        exitJMenuItem.setMnemonic('x');
        exitJMenuItem.setText("Exit");
        exitJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(exitJMenuItem);

        citiesJMenuBar.add(fileJMenu);

        sortJMenu.setMnemonic('S');
        sortJMenu.setText("Sort");
        sortJMenu.setToolTipText("Sorting options");

        menubuttonGroup.add(nameJRadioButtonMenuItem);
        nameJRadioButtonMenuItem.setMnemonic('n');
        nameJRadioButtonMenuItem.setSelected(true);
        nameJRadioButtonMenuItem.setText("By name");
        nameJRadioButtonMenuItem.setToolTipText("Sort by name and display only name");
        nameJRadioButtonMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameJRadioButtonMenuItemActionPerformed(evt);
            }
        });
        sortJMenu.add(nameJRadioButtonMenuItem);

        menubuttonGroup.add(goalsJRadioButtonMenuItem);
        goalsJRadioButtonMenuItem.setMnemonic('g');
        goalsJRadioButtonMenuItem.setText("By goals scored");
        goalsJRadioButtonMenuItem.setToolTipText("Sort player by number of goals scored");
        goalsJRadioButtonMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goalsJRadioButtonMenuItemActionPerformed(evt);
            }
        });
        sortJMenu.add(goalsJRadioButtonMenuItem);

        citiesJMenuBar.add(sortJMenu);

        actionJMenu.setMnemonic('t');
        actionJMenu.setText("Database Management");
        actionJMenu.setToolTipText("Add, Edit, Delete and more");

        addJMenuItem.setMnemonic('A');
        addJMenuItem.setText("Add");
        addJMenuItem.setToolTipText("Add new player");
        addJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(addJMenuItem);

        deleteJMenuItem.setMnemonic('D');
        deleteJMenuItem.setText("Delete");
        deleteJMenuItem.setToolTipText("Delete selected player");
        deleteJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(deleteJMenuItem);

        editJMenuItem.setMnemonic('E');
        editJMenuItem.setText("Edit");
        editJMenuItem.setToolTipText("Edit selected player");
        editJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(editJMenuItem);

        searchJMenuItem.setMnemonic('r');
        searchJMenuItem.setText("Search");
        searchJMenuItem.setToolTipText("Search for a player");
        searchJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(searchJMenuItem);

        detailsJMenuItem.setMnemonic('t');
        detailsJMenuItem.setText("Details");
        detailsJMenuItem.setToolTipText("Display picture and details of a selected player");
        detailsJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailsJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(detailsJMenuItem);

        citiesJMenuBar.add(actionJMenu);

        helpJMenu.setMnemonic('H');
        helpJMenu.setText("Help");
        helpJMenu.setToolTipText("About form");

        aboutJMenuItem.setMnemonic('A');
        aboutJMenuItem.setText("About");
        aboutJMenuItem.setToolTipText("Display about form");
        aboutJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutJMenuItemActionPerformed(evt);
            }
        });
        helpJMenu.add(aboutJMenuItem);

        citiesJMenuBar.add(helpJMenu);

        setJMenuBar(citiesJMenuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       addJButtonActionPerformed
     * Description  Event handler for adding a player by invoking the AddPlayer form.
     *              No empty or duplicate player is added. The new player is added to
     *              the JList and saved in the Player.txt file
     * Date         1/22/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void addJButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_addJButtonActionPerformed
    {//GEN-HEADEREND:event_addJButtonActionPerformed
        // Add new Player
        try {
            // Create and display a new AddDialog
            AddPlayer addPlayer = new AddPlayer();
            addPlayer.setVisible(true);
            
            // The modal dialog takes focus, upon regaining focus:
            Player newPlayer = addPlayer.getPlayer();
            if (newPlayer != null && !playerExists(newPlayer)) 
            {
                // add the new city to the database
                players.add(newPlayer);
                displayPlayers();
                searchPlayer(newPlayer.getName());
                
                // save new city to file
                savePlayers(fileName);
                
                        
            }
            else {
                playersJList.setVisible(true);
                playersJList.setSelectedIndex(0);
            }
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Player not added",
                    "Add Player Error", JOptionPane.WARNING_MESSAGE);
            playersJList.setVisible(true);
            playersJList.setSelectedIndex(0);
        }
    }//GEN-LAST:event_addJButtonActionPerformed
       

    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       newJMenuItemActionPerformed
     * Description  Show a JFileChooser with an OpenDialog to select a different
     *              players Database
     * Date         01/27/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt ActionEvent
     * @throws      IOException
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void newJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_newJMenuItemActionPerformed
    {//GEN-HEADEREND:event_newJMenuItemActionPerformed
        //Bring up JFileChooser to select file in curent directory
        JFileChooser chooser = new JFileChooser("src/Data");
        //Filter only txt files
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
        "Txt Files", "txt");
        chooser.setFileFilter(filter);
        int choice = chooser.showOpenDialog(null);
        if (choice == JFileChooser.APPROVE_OPTION) {
            //Clear existing cities ArrayList and JList
            players.clear();
            playersJList.removeAll();
            File chosenFile = chooser.getSelectedFile();
            String file = "src/Data/" + chosenFile.getName();
            
            // need to update fileName to save changes in correct file -- cannot be final
            fileName = file;
            System.out.println("file = " + file);
            readFromFile(file);
            displayPlayers();
        }
        else   // weird I/O error
        {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }

}//GEN-LAST:event_newJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       printJMenuItemActionPerformed
     * Description  Print the details of an individual player using printJButton
     *              evt handler
     * Date         1/2u7/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void printJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_printJMenuItemActionPerformed
    {//GEN-HEADEREND:event_printJMenuItemActionPerformed
        printJButtonActionPerformed(evt);
}//GEN-LAST:event_printJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       exitJMenuItemActionPerformed
     * Description  Exit the application using exitJButtonActionPerformed evt handler
     * Date         1/08/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void exitJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitJMenuItemActionPerformed
    {//GEN-HEADEREND:event_exitJMenuItemActionPerformed
        exitJButtonActionPerformed(evt);
}//GEN-LAST:event_exitJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       nameJRadioButtonMenuItemActionPerformed
     * Description  Sort the playerJList by name by calling displayPlayers() when 
     *              the nameJRadioButton is selected
     * Date         1/14/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void nameJRadioButtonMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_nameJRadioButtonMenuItemActionPerformed
    {//GEN-HEADEREND:event_nameJRadioButtonMenuItemActionPerformed
        displayPlayers();
        

}//GEN-LAST:event_nameJRadioButtonMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       goalsJRadioButtonMenuItemActionPerformed
    * Description  Sort the playerJList by goals by calling displayPlayers() 
    *              when the goalsJRadioButton is selected
    * Date         1/14/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void goalsJRadioButtonMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_goalsJRadioButtonMenuItemActionPerformed
    {//GEN-HEADEREND:event_goalsJRadioButtonMenuItemActionPerformed
        displayPlayers();
        
}//GEN-LAST:event_goalsJRadioButtonMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       addJMenuItemActionPerformed
    * Description  Calls the addJButton event handler to add a new player
    * Date         1/14/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void addJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_addJMenuItemActionPerformed
    {//GEN-HEADEREND:event_addJMenuItemActionPerformed
        // call buttonAddActionPerformed
        addJButtonActionPerformed(evt);
}//GEN-LAST:event_addJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       deleteJMenuItemActionPerformed
    * Description  Calls the deleteJButton event handler to delete a player
    * Date         1/14/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void deleteJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_deleteJMenuItemActionPerformed
    {//GEN-HEADEREND:event_deleteJMenuItemActionPerformed
        // call buttonDeleteActionPerformed
        deleteJButtonActionPerformed(evt);
}//GEN-LAST:event_deleteJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       editJMenuItemActionPerformed
    * Description  Call the editJButtonActionPerformed evt handler to edit player
    * Date         1/08/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void editJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_editJMenuItemActionPerformed
    {//GEN-HEADEREND:event_editJMenuItemActionPerformed
        // call buttonEditActionPerformed
        editJButtonActionPerformed(evt);
}//GEN-LAST:event_editJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       aboutJMenuItemActionPerformed
    * Description  Event handler to create an About Splash JDialog and display the
    *              window
    * Date         1/27/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void aboutJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_aboutJMenuItemActionPerformed
    {//GEN-HEADEREND:event_aboutJMenuItemActionPerformed
        About myAbout = new About(this,true);
        myAbout.setVisible(true);
}//GEN-LAST:event_aboutJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       searchJMenuItemActionPerformed
    * Description  Event handler for searchJMenuItem. It calls searchPlayer method
    * Date         1/27/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void searchJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_searchJMenuItemActionPerformed
    {//GEN-HEADEREND:event_searchJMenuItemActionPerformed
        String playerName = JOptionPane.showInputDialog("Enter name of player");
        // Safety check: Exit if the user clicked "Cancel" or left it blank
        if (playerName == null || playerName.trim().isEmpty()) {
            return; 
        }

        // Capture the result of the search
        Player foundPlayer = searchPlayer(playerName);

        // If search failed, stop here to avoid using a 'null' player
        if (foundPlayer == null) {
            return;
        }
    }//GEN-LAST:event_searchJMenuItemActionPerformed
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       exitJButtonActionPerformed
     * Description  Exit the application using evt handler
     * Date         1/08/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void exitJButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitJButtonActionPerformed
    {//GEN-HEADEREND:event_exitJButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitJButtonActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       playersJListValueChanged
     * Description  Call showPlayerData() to display player's data when value in
     *              playersJList has changed
     * Date         1/08/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ListSelectionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void playersJListValueChanged(javax.swing.event.ListSelectionEvent evt)//GEN-FIRST:event_playersJListValueChanged
    {//GEN-HEADEREND:event_playersJListValueChanged
        int index = (playersJList.getSelectedIndex());
        if (index >= 0)
            showPlayerData(index);
    }//GEN-LAST:event_playersJListValueChanged

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       editJButtonActionPerformed
     * Description  Event handler for the editJButton to invoke the EditPlayer
     *              JDialog
     * Date         1/28/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void editJButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_editJButtonActionPerformed
    {//GEN-HEADEREND:event_editJButtonActionPerformed
        try {
            // get name of selected player
            String playerName = playersJList.getSelectedValue().toString();
            
            // remove goals if edit mode is on sorted players by goals
            if (playerName.contains(","))
                playerName = playerName.substring(0,playerName.indexOf(','));
            
            // create a temp player to populate fields of form
            Player playerToEdit = new Player(searchPlayer(playerName));
            int index = playersJList.getSelectedIndex();
            
            // pass city info to EditPlayer constructor and view edit form
            EditPlayer editedPlayer = new EditPlayer(playerToEdit);
            editedPlayer.setVisible(true);
            
            // get edited player and add to array list
            if (editedPlayer.getPlayer() != null) {
                // remove old player from ArrayList
                players.remove(index);
                // add edited player to ArrayList
                players.add(editedPlayer.getPlayer());
                savePlayers(fileName);
                displayPlayers();
            }
            
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Player not edited",
                    "Edit Player Error", JOptionPane.WARNING_MESSAGE);
            playersJList.setVisible(true);
            playersJList.setSelectedIndex(0);
        }
    }//GEN-LAST:event_editJButtonActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       deleteJButtonActionPerformed
     * Description  Event handler for the deleteJButton to delete the selected player
     *              from the JList and the database
     * Date         1/28/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void deleteJButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_deleteJButtonActionPerformed
    {//GEN-HEADEREND:event_deleteJButtonActionPerformed
        // Delete selected player, do nothing on Cancel
        try {
        int index = playersJList.getSelectedIndex();
        String name = players.get(index).getName();
        int result = JOptionPane.showConfirmDialog(null, 
                "Are you sure you wish to delete " + name + "?", "Delete Player",
                JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            index = playersJList.getSelectedIndex();
            players.remove(index);
            displayPlayers();
            savePlayers(fileName);
        }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Player not deleted",
                    "Delete Player Error", JOptionPane.WARNING_MESSAGE);
            playersJList.setVisible(true);
            playersJList.setSelectedIndex(0);
        }
    }//GEN-LAST:event_deleteJButtonActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       printJButtonActionPerformed
     * Description  Event handler for printJButton to create a JTextArea and
     *              populate with player information and print it
     * Date         1/27/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
     * @see         java.awt.print.PrinterException
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void printJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printJButtonActionPerformed
        
        int index = playersJList.getSelectedIndex();
        JTextArea printPlayer = new JTextArea();
        if(index >= 0) {
            try {
                Player temp = new Player(players.get(index));
                String output = "Name: " + temp.getName() + "\n" +
                        "Team: " + temp.getTeam() + "\n" +
                        "Birthday: " + temp.getBirth() + "\n" +
                        "Salary: " + dollars.format(temp.getSalary()) + "\n" +
                        "Country: " + temp.getCountry() + "\n" +
                        "Games Played: " + temp.getGames() + "\n" +
                        "Goals Scored: " + temp.getGoals();
                printPlayer.setText(output);
                printPlayer.print();
                //System.out.println(output);  // print line for troubleshooting
            }
            catch (PrinterException ex) {
                JOptionPane.showMessageDialog(null, "Player not Printed",
                        "Print Error", JOptionPane.WARNING_MESSAGE);
            }
        }
        
    }//GEN-LAST:event_printJButtonActionPerformed
     /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       printFormJMenuItemActionPerformed
     * Description  Call PrintUtilities class to print the GUI
     * Date         1/08/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void printFormJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printFormJMenuItemActionPerformed
        PrintUtilities.printComponent(this);
    }//GEN-LAST:event_printFormJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       saveJMenuItemActionPerformed
     * Description  Save the data of selected player to an external text file
     * Date         1/26/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void saveJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveJMenuItemActionPerformed
        try {
            int index = playersJList.getSelectedIndex();
            if (index >= 0) {
                Player playerToSave = players.get(index);
                savePlayer(playerToSave);

                JOptionPane.showMessageDialog(null, "Player " +
                        playerToSave.getName() + " saved","Save result",
                JOptionPane.INFORMATION_MESSAGE);
                }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Player not Saved",
                        "File Error", JOptionPane.WARNING_MESSAGE);        
        }
    }//GEN-LAST:event_saveJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       detailsJMenuItemActionPerformed
     * Description  Creates a new Detail JDialog object and passes the selected
     *              player as an argument to show the player's details.
     * Date         1/29/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void detailsJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailsJMenuItemActionPerformed
        Detail playerDetail;
        int index = playersJList.getSelectedIndex();
        // alternative: get name from JList and search for player with that name
        if (index >= 0) {
            Player footballer = new Player(players.get(index));
            playerDetail = new Detail(footballer);
            playerDetail.setVisible(true);
        }
    }//GEN-LAST:event_detailsJMenuItemActionPerformed
      
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
     * Method       main()
     * Description  Displays splash screen and main Footballers GUI form
     * Date         1/14/2026   
     * History log 
     * @param       args is the command line string array
     * @author      <i>Arthur Rahman</i>
     *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static void main(String args[])
    {      
        // show splash screen
        Splash mySplash = new Splash(3000);
        //mySplash.showSplash();
        
        FootballersGUI usaCities = new FootballersGUI();
        usaCities.setLocationRelativeTo(null);
        usaCities.setVisible(true);
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutJMenuItem;
    private javax.swing.JMenu actionJMenu;
    private javax.swing.JButton addJButton;
    private javax.swing.JMenuItem addJMenuItem;
    private javax.swing.JLabel birthJLabel;
    private javax.swing.JTextField birthJTextField;
    private javax.swing.JMenuBar citiesJMenuBar;
    private javax.swing.JPanel controlPanel;
    private javax.swing.JLabel countryJLabel;
    private javax.swing.JTextField countryJTextField;
    private javax.swing.JButton deleteJButton;
    private javax.swing.JMenuItem deleteJMenuItem;
    private javax.swing.JMenuItem detailsJMenuItem;
    private javax.swing.JPanel displayJPanel;
    private javax.swing.JButton editJButton;
    private javax.swing.JMenuItem editJMenuItem;
    private javax.swing.JButton exitJButton;
    private javax.swing.JMenuItem exitJMenuItem;
    private javax.swing.JMenu fileJMenu;
    private javax.swing.JPopupMenu.Separator fileJSeparator;
    private javax.swing.JLabel gamesJLabel;
    private javax.swing.JTextField gamesJTextField;
    private javax.swing.JLabel goalsJLabel;
    private javax.swing.JRadioButtonMenuItem goalsJRadioButtonMenuItem;
    private javax.swing.JTextField goalsJTextField;
    private javax.swing.JMenu helpJMenu;
    private javax.swing.JPanel listJPanel;
    private javax.swing.JScrollPane llistJScrollPane;
    private javax.swing.JLabel logoJLabel;
    private javax.swing.ButtonGroup menubuttonGroup;
    private javax.swing.JLabel nameJLabel;
    private javax.swing.JRadioButtonMenuItem nameJRadioButtonMenuItem;
    private javax.swing.JTextField nameJTextField;
    private javax.swing.JMenuItem newJMenuItem;
    private javax.swing.JList playersJList;
    private javax.swing.JMenuItem printFormJMenuItem;
    private javax.swing.JButton printJButton;
    private javax.swing.JMenuItem printJMenuItem;
    private javax.swing.JLabel salaryJLabel;
    private javax.swing.JTextField salaryJTextField;
    private javax.swing.JMenuItem saveJMenuItem;
    private javax.swing.JMenuItem searchJMenuItem;
    private javax.swing.JMenu sortJMenu;
    private javax.swing.JLabel teamJLabel;
    private javax.swing.JTextField teamJTextField;
    private javax.swing.JLabel titleJLabel;
    private javax.swing.JPanel titleJPanel;
    private javax.swing.JLabel websiteJLabel;
    private javax.swing.JTextField websiteJTextField;
    // End of variables declaration//GEN-END:variables
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       searchPlayer()
    * Description  Search for a player by name and highlight if found
    * Date         01/22/2026     
    * History log 
    * @param       playerName String
    * @author      <i>Arthur Rahman</i>
    * @return      Player
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private Player searchPlayer(String playerName) {
        int index = -1; // default player not found
        if ((playerName != null) && (playerName.length() > 0)) {
            //Sort the JList of player by name
            nameJRadioButtonMenuItem.setSelected(true);
            displayPlayers();
            
            // Remove accent marks from player name
            String cleanInput = Validation.flatten(playerName);
            
            //Create a String array of player names
            String[] playerArray = new String[players.size()];
            for (int i = 0; i < playerArray.length; i++)
                playerArray[i] = Validation.flatten(players.get(i).getName().toLowerCase());
            //Find index of player
            index = linearSearch(playerArray, cleanInput);
            if (index < 0) {
                JOptionPane.showMessageDialog(null, "Player " + playerName +
                        " not found", "Search result", JOptionPane.WARNING_MESSAGE);
                if (players.size() > 0) 
                    playersJList.setSelectedIndex(0);
                else
                    playersJList.clearSelection();
                    
                return null;
            }
            else
                playersJList.setSelectedIndex(index);
                return players.get(index);
            
        }
        return null;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       linearSearch
    * Description  Method to search player by name using the linear search algorithm
    *              and to display its index if found and -1 if not found
    * Date         1/27/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       playerArray String[]
    * @param       playerName String
    * @return      index int
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private int linearSearch(String[] playerArray, String playerName) {
        int index = -1;
        boolean found = false;
        for (int i = 0; i < playerArray.length && !found; i++) {
            if (playerArray[i].toLowerCase().contains(playerName.toLowerCase())) {
                index = i;
                found = true;
            }
    }
        return index;
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       savePlayer
    * Description  Method that save a single player to its own file
    * Date         1/27/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       player Player
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void savePlayer(Player player) throws IOException {
        String fileName = "src/Data/" + player.getName() + ".txt";
        try (PrintWriter output = new PrintWriter(new FileWriter(fileName))) {
            output.print(player.toString());
            output.close();
        }
        
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       savePlayers
    * Description  Method that writes all players to an external comma delimited
    *              text file
    * Date         1/27/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       fileName String
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void savePlayers(String fileName) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(fileName))) {
            for (Player p : players) {
                out.println(p.toCSV());
            }
            out.close();
        }
    }

}