package Footballers;

import java.net.MalformedURLException;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTextField;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        Validation.java
 * Description  Provides a number of boolean methods for validating different
 *              types using regular expressions
 * Project      Project 1-Footballers
 * Platform     jdk 25.0.1; Apache NetBeans IDE 28; Mac OS X version 15.6.1
 * Course       CS 142--Lab 1-3, Winter 2025, Edmonds College
 * Hours        1 hour
 * @author	<i>Arthur Rahman</i>
 * @version 	%1%
 * Date         01/27/2026
 * History Log    	
 * @see         java.util.regex.Matcher
 * @see         java.util.regex.Pattern
 *</pre>
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class Validation {
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isDouble()    
     * Description  Validates that double value is entered
     * @author      <i>Arthur Rahman</i>
     * @param       fieldValue String, input
     * @return      boolean
     * Date         01/22/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isDouble(String fieldValue) {
        String cleaned = fieldValue.replaceAll("[$,]", "");
        Pattern pat = Pattern.compile("\\d+(\\.\\d+)?");
        Matcher mat = pat.matcher(cleaned);
        return mat.matches();
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isDouble()    
     * Description  Overloaded, validates that double value is entered within
     *              the required range
     * @author      <i>Arthur Rahman</i>
     * @param       fieldValue String, input
     * @param       lower double, lower bound
     * @param       upper double, upper bound
     * @return      boolean
     * Date         01/22/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isDouble(String fieldValue, double lower, double upper) {
        String cleaned = fieldValue.replaceAll("[$,]", "").trim();
        boolean result = true;
        Pattern pat = Pattern.compile("\\d+(\\.\\d+)?");
        Matcher mat = pat.matcher(cleaned);
        if (mat.matches()) {
            try {
                // check range 
                double num = Double.parseDouble(cleaned);
                if (num < lower || num > upper)
                    result = false;
            }
            catch (NumberFormatException ex) {
                // something went wrong
                result = false;
            }
        }
        else
            result = false;
        return result;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isInteger()    
     * Description  Validates that integer value is entered 
     * @author      <i>Arthur Rahman</i>
     * @param       fieldValue String, input
     * @return      boolean
     * Date         01/22/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isInteger(String fieldValue) {
        Pattern pat = Pattern.compile("\\d+");
        Matcher mat = pat.matcher(fieldValue);
        return mat.matches();
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isEmpty()    
     * Description  Validates that JTextField is not empty
     * @author      <i>Arthur Rahman</i>
     * @param       fieldValue JTextField, input
     * @return      boolean
     * @see         javax.swing.JTextField
     * Date         01/22/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isEmpty(JTextField fieldValue) {
        String input = fieldValue.getText();
        if (input == null || input.length() <= 0 || input.equals(""))
            return true;
        else
            return false;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isValidName()    
     * Description  Validates that JTextField is a valid player name
     * @author      <i>Arthur Rahman</i>
     * @param       input String, input
     * @return      boolean
     * Date         01/22/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isValidName(String input) {
        final short MAX_LENGTH = 30;
        final short MIN_LENGTH = 2;
        boolean result = true;
        Pattern pat = Pattern.compile("^[\\p{L}\\s\\.\\-']{2,30}$");
        Matcher mat = pat.matcher(input);
        if(!mat.matches() || input.length() > MAX_LENGTH || input.length() < MIN_LENGTH)
            result = false;
        return result;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isDate()    
     * Description  Validates that JTextField is a valid date
     * @author      <i>Arthur Rahman</i>
     * @param       input String, input
     * @return      boolean
     * Date         01/22/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isDate(String input) {
        //SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        // Match format like: 6 January 2008, 21 July 1999
        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM yyyy");
        sdf.setLenient(false); // ensures strict parsing
        try {
            sdf.parse(input);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       isDate()    
     * Description  Validates that JTextField is a valid Url
     * @author      <i>Arthur Rahman</i>
     * @param       input String, input
     * @return      boolean
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static boolean isValidURL(String input) {
        if (input == null || input.isEmpty()) {
            return true;
        }
        return input.matches("^https?://.*");
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       flatten
    * Description  Method to seperate accents from the letters of a String using
    *              a regular expression 
    * Date         1/27/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       text String
    * @return      String
    * @see         java.text.Normalizer
    * @see         java.util.regex.Pattern
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static String flatten(String text) {
        if (text == null) return "";
        // Separate accents from letters (e.g., 'é' becomes 'e' + '´')
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFD);
        // Remove all non-spacing marks (the accents)
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(normalized).replaceAll("").toLowerCase();
    }

    
}
