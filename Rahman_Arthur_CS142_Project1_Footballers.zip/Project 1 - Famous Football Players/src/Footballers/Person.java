package Footballers;

import java.util.Objects;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        Player.java
 * Description  An abstract class Person with appropriate private instance 
 *              variables (name and birthday) from which Player class is derived.
 * Project      Project 1 - Famous Football Players
 * Platform     jdk 25.0.1; Apache NetBeans IDE 28; Mac OS X version 15.6.1
 * Course       CS 142--Lab 1-3, Winter 2025, Edmonds College
 * Hours        30 minutes
 * @author	<i>Arthur Rahman</i>
 * @version 	%1%
 * Date         01/29/2026
 * History Log    	
 *</pre>
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public abstract class Person {
    private String name;
    private String birth;
    
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Constructor  Person()-default constructor
     * Description  Create an instance of the Person class and assign default 
     *              values to all fields
     * @author      <i>Arthur Rahman</i>
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Person() {
        name = "";
        birth = "";
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Constructor  Person()-overloaded constructor
     * Description  Create an instance of the Person class and assign parameter 
     *              values to all fields
     * @param       name String
     * @param       birth String
     * @author      <i>Arthur Rahman</i>
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public Person(String name, String birth) {
        this.name = name;
        this.birth = birth;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       getName()    
     * Description  Get method to return instance variable name
     * @author      <i>Arthur Rahman</i>
     * @return      name String
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String getName() {
        return name;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       setName()    
     * Description  Set method to set instance variable name
     * @author      <i>Arthur Rahman</i>
     * @param       name String
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setName(String name) {
        this.name = name;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       getBirth()    
     * Description  Get method to return instance variable birth
     * @author      <i>Arthur Rahman</i>
     * @return      birth String
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String getBirth() {
        return birth;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       setBirth()    
     * Description  Set method to set instance variable birth
     * @author      <i>Arthur Rahman</i>
     * @param       birth String
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setBirth(String birth) {
        this.birth = birth;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       hashCode() -overridden
     * Description  Overriden hashCode() method to generate unique hash code
     * @author      <i>Arthur Rahman</i>
     * @return      hashCode int
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override   
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + Objects.hashCode(this.name);
        hash = 13 * hash + Objects.hashCode(this.birth);
        return hash;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       equals() 
     * Description  Overriden method to check if one Person object equals to
     *              another
     * @author      <i>Arthur Rahman</i>
     * @param       obj Object
     * @return      true or false boolean
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return Objects.equals(this.birth, other.birth);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       toString() 
     * Description  Overriden toString() method to display a Person object
     * @author      <i>Arthur Rahman</i>
     * @return      Person object String
     * Date         01/29/2026
     * History Log  
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", birth=" + birth + '}';
    }
    
    
    
    
    
    
    
    
    
}
