package TwoCards;

import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeSet;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        TwoCardsGUI.java
 * Description  JFrame GUI for the Two Cards game. As the program starts, the 
 *              program reads from a comma-delimited external file, Players1.txt 
 *              with three fields: name,age, and initial balance given ($1,000 
 *              money given to start off). Each comma-delimited line in this 
 *              file should represent a player’s name, age and balance. A Player
 *              object is created for each line read, from a Player class you 
 *              have to create, derived from an abstract class, Person.
 * Project      Project 3--Two Cards Game
 * Platform     JDK 25.0.1; NetBeans IDE 28; Mac OS X version 26.3 
 * Course       CS 142
 * Hours        3 hours
 * Date         3/2/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1%
 * @see         java.text.DecimalFormat
 * @see         javax.swing.JFrame
 * @see         java.util.TreeSet
 * @see         DeckOfCards
 * @see         javax.swing.DefaultListModel
 *</pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class TwoCardsGUI extends javax.swing.JFrame {   
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TwoCardsGUI.class.getName());
    private String fileName = "src/Data/Players1.txt";
    private TreeSet<Player> players = new TreeSet<Player>();
    DeckOfCards myDeck = new DeckOfCards();
    DefaultListModel model = new DefaultListModel();
    private String output = null;
    private final double ODDS = 20;                     // odds to play the game
    private final int NUM_CARDS = 2;                    // number of cards drawn
    private int[] cards = new int[NUM_CARDS];           // index of cards drawn
    private int[] cardValue = new int[NUM_CARDS];       // value of cards drawn
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre> 
     * Constructor  TwoCardsGUI()--default constructor
     * Description  Create the form as designed, center it, set the icon, 
     *              drawJButton as default.
     * Date         3/3/2026
     * History log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public TwoCardsGUI() {
        initComponents();
        this.setIconImage(Toolkit.getDefaultToolkit().getImage("src/CardsImages/icon.png"));
        this.setLocationRelativeTo(null);
        this.getRootPane().setDefaultButton(drawJButton);
        readFromFile(fileName);
        playersJList.setModel(model);
        playersJList.setSelectedIndex(0);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method	        readFromFile()
    * Description       Method that reads Players from a text file that is comma
    *                   delimited and creates an instance of the Player class 
    *                   with the data read.
    * @param		fileName String
    * @see              java.io.File
    * @see              java.io.FileNotFoundException
    * @see              java.util.Scanner
    * @see              javax.swing.filechooser.FileNameExtensionFilter
    * @author           <i>Arthur Rahman</i>
    * Date              3/3/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void readFromFile(String fileName) {
        players.clear(); // clear the TreeSet
        try {
            Scanner input = new Scanner(new File(fileName));
            String line = "";
            Player player = null;
            StringTokenizer token = null;
            while (input.hasNextLine()) {
                line = input.nextLine();
                player = new Player();
                token = new StringTokenizer(line, ",");
                    while (token.hasMoreElements()) {
                        player.setName(token.nextToken());
                        player.setAge(Integer.parseInt(token.nextToken()));
                        player.setBalance(Double.parseDouble(token.nextToken()));
                    }
                    // add city to TreeSet
                    players.add(player);
                }
                input.close();
                displayPlayers();
        }
        catch(FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, fileName + " does not exist",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
            // Bring up JFileChooser to select file in curent directory
            JFileChooser chooser = new JFileChooser("src/Data");
            // Filter only txt files
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Txt Files", "txt");
            chooser.setFileFilter(filter);
            int choice = chooser.showOpenDialog(null);
            if (choice == JFileChooser.APPROVE_OPTION) {
                File chosenFile = chooser.getSelectedFile();
                fileName = "src/Data/" + chosenFile.getName();
                System.out.println("file = " + fileName);
                readFromFile(fileName);
            }
            else {
                JOptionPane.showMessageDialog(null, "Unable to read file",
                        "File Input Error", JOptionPane.WARNING_MESSAGE);
            }
        }
        
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       displayPlayers
     * Description  Displays players in JList sorted by TreeSet
     * Date         1/14/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void displayPlayers() {
        model.clear();
        for (Player player : players) {
            model.addElement(player);
        }   
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titleJLabel = new javax.swing.JLabel();
        cardJLabel2 = new javax.swing.JLabel();
        cardJLabel1 = new javax.swing.JLabel();
        betJLabel = new javax.swing.JLabel();
        betJTextField = new javax.swing.JTextField();
        playersJScrollPane = new javax.swing.JScrollPane();
        playersJList = new javax.swing.JList<>();
        clearJButton = new javax.swing.JButton();
        drawJButton = new javax.swing.JButton();
        instructionsJScrollPane = new javax.swing.JScrollPane();
        instructionsJTextArea = new javax.swing.JTextArea();
        resultsJScrollPane = new javax.swing.JScrollPane();
        resultsJTextArea = new javax.swing.JTextArea();
        replacementJCheckBox = new javax.swing.JCheckBox();
        fileJMenuBar = new javax.swing.JMenuBar();
        fileJMenu = new javax.swing.JMenu();
        newJMenuItem = new javax.swing.JMenuItem();
        printJMenuItem = new javax.swing.JMenuItem();
        printFormJMenuItem = new javax.swing.JMenuItem();
        saveJMenuItem = new javax.swing.JMenuItem();
        exitJMenuItem = new javax.swing.JMenuItem();
        databaseJMenu = new javax.swing.JMenu();
        addJMenuItem = new javax.swing.JMenuItem();
        editJMenuItem = new javax.swing.JMenuItem();
        deleteJMenuItem = new javax.swing.JMenuItem();
        searchJMenuItem = new javax.swing.JMenuItem();
        detailsJMenuItem = new javax.swing.JMenuItem();
        helpJMenu = new javax.swing.JMenu();
        aboutJMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Two Cards Game");
        setResizable(false);

        titleJLabel.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        titleJLabel.setForeground(new java.awt.Color(153, 0, 51));
        titleJLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleJLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CardsImages/icon.png"))); // NOI18N
        titleJLabel.setText("Welcome to Two Cards Game");

        cardJLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CardsImages/53.png"))); // NOI18N

        cardJLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CardsImages/54.png"))); // NOI18N

        betJLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        betJLabel.setText("What is your bet: ");

        betJTextField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        betJTextField.setToolTipText("Enter amount to bet for this game (leave blank for $0)");
        betJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                betJTextFieldKeyTyped(evt);
            }
        });

        playersJScrollPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Players", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 3, 13), new java.awt.Color(153, 0, 51))); // NOI18N
        playersJScrollPane.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N

        playersJList.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        playersJList.addListSelectionListener(this::playersJListValueChanged);
        playersJScrollPane.setViewportView(playersJList);

        clearJButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        clearJButton.setMnemonic('C');
        clearJButton.setText("Clear");
        clearJButton.setToolTipText("Restore GUI to original state");
        clearJButton.addActionListener(this::clearJButtonActionPerformed);

        drawJButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        drawJButton.setMnemonic('D');
        drawJButton.setText("Draw Cards");
        drawJButton.setToolTipText("Draw cards to play the game (or Press Enter)");
        drawJButton.addActionListener(this::drawJButtonActionPerformed);

        instructionsJScrollPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Instructions", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 3, 13), new java.awt.Color(153, 0, 51))); // NOI18N

        instructionsJTextArea.setEditable(false);
        instructionsJTextArea.setColumns(20);
        instructionsJTextArea.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        instructionsJTextArea.setLineWrap(true);
        instructionsJTextArea.setRows(5);
        instructionsJTextArea.setText("Enter amount (or leave blank) willing to bet in order to play this game: two cards are drawn randomly without replacement. If they are the same value, you win 20 times your bet; else you will lose your bet. Click on Draw Cards when ready!");
        instructionsJTextArea.setWrapStyleWord(true);
        instructionsJScrollPane.setViewportView(instructionsJTextArea);

        resultsJScrollPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Results", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 3, 13), new java.awt.Color(153, 0, 51))); // NOI18N

        resultsJTextArea.setEditable(false);
        resultsJTextArea.setColumns(20);
        resultsJTextArea.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        resultsJTextArea.setRows(5);
        resultsJScrollPane.setViewportView(resultsJTextArea);

        replacementJCheckBox.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        replacementJCheckBox.setText(" Play with Replacement");
        replacementJCheckBox.setToolTipText("Check for replacing the first card back into the deck when the second is drawn.");

        fileJMenu.setMnemonic('F');
        fileJMenu.setText("File");

        newJMenuItem.setMnemonic('N');
        newJMenuItem.setText("New");
        newJMenuItem.setToolTipText("Open a new set of players");
        newJMenuItem.addActionListener(this::newJMenuItemActionPerformed);
        fileJMenu.add(newJMenuItem);

        printJMenuItem.setMnemonic('P');
        printJMenuItem.setText("Print");
        printJMenuItem.setToolTipText("Print individual player details");
        printJMenuItem.addActionListener(this::printJMenuItemActionPerformed);
        fileJMenu.add(printJMenuItem);

        printFormJMenuItem.setMnemonic('F');
        printFormJMenuItem.setText("Print Form");
        printFormJMenuItem.setToolTipText("Print form as GUI");
        printFormJMenuItem.addActionListener(this::printFormJMenuItemActionPerformed);
        fileJMenu.add(printFormJMenuItem);

        saveJMenuItem.setMnemonic('S');
        saveJMenuItem.setText("Save");
        saveJMenuItem.setToolTipText("Save player details to external text file");
        saveJMenuItem.addActionListener(this::saveJMenuItemActionPerformed);
        fileJMenu.add(saveJMenuItem);

        exitJMenuItem.setMnemonic('x');
        exitJMenuItem.setText("Exit");
        exitJMenuItem.setToolTipText("Quit the application");
        exitJMenuItem.addActionListener(this::exitJMenuItemActionPerformed);
        fileJMenu.add(exitJMenuItem);

        fileJMenuBar.add(fileJMenu);

        databaseJMenu.setMnemonic('r');
        databaseJMenu.setText("Players Database");

        addJMenuItem.setMnemonic('A');
        addJMenuItem.setText("Add New Player");
        addJMenuItem.setToolTipText("Add a new player to database");
        addJMenuItem.addActionListener(this::addJMenuItemActionPerformed);
        databaseJMenu.add(addJMenuItem);

        editJMenuItem.setMnemonic('E');
        editJMenuItem.setText("Edit Player");
        editJMenuItem.setToolTipText("Edit selected player");
        editJMenuItem.addActionListener(this::editJMenuItemActionPerformed);
        databaseJMenu.add(editJMenuItem);

        deleteJMenuItem.setMnemonic('D');
        deleteJMenuItem.setText("Delete Player");
        deleteJMenuItem.setToolTipText("Delete selected player");
        deleteJMenuItem.addActionListener(this::deleteJMenuItemActionPerformed);
        databaseJMenu.add(deleteJMenuItem);

        searchJMenuItem.setMnemonic('S');
        searchJMenuItem.setText("Search Player");
        searchJMenuItem.setToolTipText("Search for player in the database");
        searchJMenuItem.addActionListener(this::searchJMenuItemActionPerformed);
        databaseJMenu.add(searchJMenuItem);

        detailsJMenuItem.setMnemonic('t');
        detailsJMenuItem.setText("Player Details");
        detailsJMenuItem.setToolTipText("Display individual player details");
        detailsJMenuItem.addActionListener(this::detailsJMenuItemActionPerformed);
        databaseJMenu.add(detailsJMenuItem);

        fileJMenuBar.add(databaseJMenu);

        helpJMenu.setMnemonic('H');
        helpJMenu.setText("Help");

        aboutJMenuItem.setMnemonic('A');
        aboutJMenuItem.setText("About");
        aboutJMenuItem.setToolTipText("Display about form");
        aboutJMenuItem.addActionListener(this::aboutJMenuItemActionPerformed);
        helpJMenu.add(aboutJMenuItem);

        fileJMenuBar.add(helpJMenu);

        setJMenuBar(fileJMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 736, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(instructionsJScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(cardJLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(clearJButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(cardJLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(drawJButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(replacementJCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(129, 129, 129)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(betJLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(betJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(playersJScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(resultsJScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(titleJLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cardJLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cardJLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(clearJButton, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                            .addComponent(drawJButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(replacementJCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(betJLabel)
                            .addComponent(betJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(playersJScrollPane)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(resultsJScrollPane)
                    .addComponent(instructionsJScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		exitJMenuItemActionPerformed()
    * Description       Exit the application	
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @author           <i>Arthur Rahman</i>
    * Date              3/3/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void exitJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitJMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		aboutJMenuItemActionPerformed()
    * Description       Create an About form and display it
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @author           <i>Arthur Rahman</i>
    * Date              3/3/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void aboutJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutJMenuItemActionPerformed
        About myAbout = new About(this,true);
        myAbout.setVisible(true);
    }//GEN-LAST:event_aboutJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		printJMenuItemActionPerformed()
    * Description       Print the individual selected player's details. Creates
    *                   a JTextArea and fills it with player name, age, balance
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @see              javax.swing.JTextArea
    * @see              java.awt.print.PrinterException
    * @author           <i>Arthur Rahman</i>
    * Date              3/3/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void printJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printJMenuItemActionPerformed
        JTextArea printPlayer = new JTextArea();
        int indexToShow = playersJList.getSelectedIndex();
        try {
                Player temp = new Player((Player)model.get(indexToShow));
                String output = temp.getFullDetails();
                printPlayer.setText(output);
                printPlayer.print();
                //System.out.println(output);  // print line for troubleshooting
            }
            catch (PrinterException ex) {
                JOptionPane.showMessageDialog(null, "Player not Printed",
                        "Print Error", JOptionPane.WARNING_MESSAGE);
            }
    }//GEN-LAST:event_printJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		printFormJMenuItemActionPerformed()
    * Description       Print the whole GUI as a form using PrintUtilities
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @see              PrintUtilities
    * @author           <i>Arthur Rahman</i>
    * Date              3/3/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void printFormJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printFormJMenuItemActionPerformed
        PrintUtilities.printComponent(this);
    }//GEN-LAST:event_printFormJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		playersJListValueChanged()
    * Description       Display the selected Player's details into the 
    *                   resultsJTextArea: name, age, balance.
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void playersJListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_playersJListValueChanged
        int index = playersJList.getSelectedIndex();
        if (index != -1) {
            Player selected = (Player) model.get(index);
            resultsJTextArea.setText(selected.getFullDetails());
        } else {
            resultsJTextArea.setText(""); 
        }
        
    }//GEN-LAST:event_playersJListValueChanged
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		newJMenuItemActionPerformed()
    * Description       Open a JFileChooser to select a new external file to
    *                   read from and populate new Tree
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @see              javax.swing.JFileChooser
    * @see              javax.swing.filechooser.FileNameExtensionFilter
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void newJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newJMenuItemActionPerformed
        //Bring up JFileChooser to select file in curent directory
        JFileChooser chooser = new JFileChooser("src/Data");
        //Filter only txt files
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
        "Txt Files", "txt");
        chooser.setFileFilter(filter);
        int choice = chooser.showOpenDialog(null);
        if (choice == JFileChooser.APPROVE_OPTION) {
            //Clear existing players tree
            players.clear();
            //clearJButtonActionPerformed(evt);
            File chosenFile = chooser.getSelectedFile();
            String file = "src/Data/" + chosenFile.getName();
            
            // need to update fileName to save changes in correct file -- cannot be final
            fileName = file;
            System.out.println("file = " + file);
            readFromFile(fileName);
            playersJList.setSelectedIndex(0);
        }
        else   // weird I/O error
        {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_newJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		clearJButtonActionPerformed()
    * Description       Reset variables and restore GUI to original state
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void clearJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearJButtonActionPerformed
        playersJList.setSelectedIndex(0);
        resultsJTextArea.setText(((Player)model.get(0)).getFullDetails());
        betJTextField.setText("");
        replacementJCheckBox.setSelected(false);
        cardJLabel1.setIcon(new ImageIcon("src/CardsImages/54.png"));
        cardJLabel2.setIcon(new ImageIcon("src/CardsImages/53.png"));
    }//GEN-LAST:event_clearJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		saveJMenuItemActionPerformed()
    * Description       Save the data of an individual Player object to an
    *                   external TXT file (Name, Age, Balance)
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @see              java.io.IOException
    * @see              #savePlayer
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void saveJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveJMenuItemActionPerformed
        try {
            int index = playersJList.getSelectedIndex();
            if (index >= 0) {
                Player playerToSave = (Player) model.get(index);
                savePlayer(playerToSave);

                JOptionPane.showMessageDialog(null, "Player " +
                        playerToSave.getName() + " saved","Save result",
                JOptionPane.INFORMATION_MESSAGE);
                }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Player not Saved",
                        "File Error", JOptionPane.WARNING_MESSAGE);        
        }
    }//GEN-LAST:event_saveJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		addJMenuItemActionPerformed()
    * Description       Create and display an addPlayer form. Allows the user
    *                   to input new fields for a Player object. Validates input
    *                   and does not create duplicate Player (same name and age)
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @see              AddPlayer
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void addJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJMenuItemActionPerformed
        // Add new Player
        try {
            // Create and display a new AddDialog
            AddPlayer addPlayer = new AddPlayer();
            addPlayer.setVisible(true);
            
            // The modal dialog takes focus, upon regaining focus:
            Player newPlayer = addPlayer.getPlayer();
            if (newPlayer != null && !playerExists(newPlayer)) 
            {
                // add the new player to the database
                players.add(newPlayer);                
                // save new player to file
                savePlayers(fileName);
                // read appended file to update variables
                readFromFile(fileName);
                searchPlayer(newPlayer.name);      
            }
            else if (playerExists(newPlayer)) {
                JOptionPane.showMessageDialog(null, "Player already exists!",
                    "Add Player Error", JOptionPane.WARNING_MESSAGE);
                playersJList.setVisible(true);
                playersJList.setSelectedIndex(0);
            }
            else {
                playersJList.setVisible(true);
                playersJList.setSelectedIndex(0);
            }
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Player not added",
                    "Add Player Error", JOptionPane.WARNING_MESSAGE);
            playersJList.setVisible(true);
            playersJList.setSelectedIndex(0);
        }
        
    }//GEN-LAST:event_addJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		editJMenuItemActionPerformed()
    * Description       Create and display an EditPlayer form. Allows the user 
    *                   to change the existing fields of the selected Player obj
    *                   and validates the input.
    * @param		evt ActionEvent
    * @see              java.awt.event.ActionEvent
    * @see              EditPlayer
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void editJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editJMenuItemActionPerformed
        try {
            // get name of selected player
            int index = playersJList.getSelectedIndex();
            Player playerToEdit = new Player((Player) model.get(index));
            // pass player info to EditPlayer constructor and view edit form
            EditPlayer editedPlayer= new EditPlayer(playerToEdit);
            editedPlayer.setVisible(true);
            
            // get edited player and add to tree
            if (editedPlayer.getPlayer() != null) {
                // remove old player from tree
                players.remove(playerToEdit);
                // add edited player to tree
                players.add(editedPlayer.getPlayer());
                savePlayers(fileName);
                readFromFile(fileName);
                searchPlayer(editedPlayer.getPlayer().getName());
            }
            
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Player not edited",
                    "Edit Player Error", JOptionPane.WARNING_MESSAGE);
            playersJList.setVisible(true);
            playersJList.setSelectedIndex(0);
        }
    }//GEN-LAST:event_editJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       deleteJMenuItemActionPerformed
     * Description  Event handler for the deleteJMenuItem to delete the selected
     *              Player from the JList and the database
     * Date         3/9/26
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void deleteJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteJMenuItemActionPerformed

        try {
            int index = playersJList.getSelectedIndex();
            Player playerToDelete = (Player) model.get(index);
            int result = JOptionPane.showConfirmDialog(null, 
                    "Are you sure you wish to delete " + playerToDelete + "?", "Delete Player",
                    JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);

            if (result == JOptionPane.YES_OPTION) {
                players.remove(playerToDelete);
                savePlayers(fileName);
                readFromFile(fileName);
        }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Player not deleted",
                    "Delete Player Error", JOptionPane.WARNING_MESSAGE);
            playersJList.setVisible(true);
            playersJList.setSelectedIndex(0);
        }
    }//GEN-LAST:event_deleteJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       searchJMenuItemActionPerformed
    * Description  Event handler for searchJMenuItem. It calls searchPlayer() 
    *              method
    * Date         3/10/26
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void searchJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchJMenuItemActionPerformed
        String playerName = JOptionPane.showInputDialog("Enter name of player");
        // Safety check: Exit if the user clicked "Cancel" or left it blank
        if (playerName == null || playerName.trim().isEmpty()) {
            return; 
        }
        // Capture the result of the search
        Player foundPlayer = searchPlayer(playerName);

        // If search failed, stop here to avoid using a 'null' player (In case of strange Error)
        if (foundPlayer == null) {
            return;
        }
    }//GEN-LAST:event_searchJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       detailsJMenuItemActionPerformed
    * Description  Event handler for detailsJMenuItem. It creates and displays
    *              a Detail JDialog that displays individual Player's details
    *              and image.
    * Date         3/10/26
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    * @see         Detail
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void detailsJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailsJMenuItemActionPerformed
        int index = playersJList.getSelectedIndex();
        Player playerToDisplay = (Player) model.get(index);
        Detail playerDetail = new Detail(playerToDisplay);
        playerDetail.setVisible(true);
    }//GEN-LAST:event_detailsJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       drawJButtonActionPerformed
    * Description  Event handler for drawJButton. It validates the betJTextField
    *              input, generates two random cards, displays them on JLabels,
    *              evaluates if Player won, updates their balance, and then 
    *              displays the results to JTextArea. 
    * Date         3/10/26
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void drawJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drawJButtonActionPerformed
        double betAmount = 0.0;
        // grab the selected Player from Jlist
        int index = playersJList.getSelectedIndex();
        // for the strange chance that Player does not get selected
        if (index == -1) {
            JOptionPane.showMessageDialog(null, "Select a player to play!");
            return;
        }
        Player activePlayer = (Player) model.get(index);
        double playerBalance = activePlayer.getBalance();
        // grab the bet amt if there is one, and don't continue if > Player balance
        if (!betJTextField.getText().isEmpty()) {
            betAmount = Double.parseDouble(betJTextField.getText());
            if (betAmount > playerBalance) {
                JOptionPane.showMessageDialog(null, "Bet amount cannot exceed player balance!",
                    "Overdraft Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        myDeck = new DeckOfCards();
        // generate random card indexes, calculate value
        for (int i=0; i < NUM_CARDS; i++) {
            cards[i] = myDeck.getRandomCard(replacementJCheckBox.isSelected());
            cardValue[i] = (cards[i] - 1) % 13 + 1;
        }
        cardJLabel1.setIcon(new ImageIcon("src/CardsImages/" + cards[0] + ".png"));
        cardJLabel2.setIcon(new ImageIcon("src/CardsImages/" + cards[1] + ".png"));
        // calculate new balance and display results
        if (cardValue[0] == cardValue[1]) {
            activePlayer.setBalance(playerBalance + ((betAmount * ODDS) - betAmount));
            output = "Lucky! You WON!\n\n" + activePlayer.getFullDetails();
        }
        else {
            activePlayer.setBalance(playerBalance - betAmount);
            output = "Sorry. You LOST! Try Again.\n\n" + activePlayer.getFullDetails() ;
        }
        savePlayers(fileName);
        resultsJTextArea.setText(output);
    }//GEN-LAST:event_drawJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       betJTextFieldKeyTyped
    * Description  KeyTyped event handler for the betJTextField to ensure only
    *              digits and backspaces are entered. Pressing enter will fire
    *              the drawJButton.
    * @param       evt ava.awt.event.KeyEvent
    * Date         3/9/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void betJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_betJTextFieldKeyTyped
        char ch = evt.getKeyChar();
        if (!Character.isDigit(ch) && ch != '\b') {
            evt.consume(); // Ignore the character
            //JOptionPane.showMessageDialog(null, "Please enter digits only.");
            return;
        }
        if (ch == '\n') { // Enter key
            drawJButton.doClick();
        }
    }//GEN-LAST:event_betJTextFieldKeyTyped

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       savePlayer
    * Description  Method that save a single player to its own file
    * @param       player Player
    * @see         java.io.FileWriter
    * @see         java.io.PrintWriter
    * Date         3/9/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void savePlayer(Player player) throws IOException {
        String fileName = "src/Data/" + player.getName() + ".txt";
        try (PrintWriter output = new PrintWriter(new FileWriter(fileName))) {
            output.print(player.toCSV());
            output.close();
        }
        
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       savePlayers
    * Description  Method to save newly added players to the external TXT file
    * Date         3/9/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       fileName String
    * @see         java.io.PrintWriter
    * @see         java.io.FileWriter
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void savePlayers(String fileName) {
        try (PrintWriter out = new PrintWriter(new FileWriter(fileName))) {
        for (Player player : players) {
            out.println(player.toCSV());
        }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, fileName + " not saved",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       playerExists
     * Description  Determine if player passed in parameter exits
     * Date         3/9/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       anotherPlayer Player
     * @return      thereIsOne - boolean
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private boolean playerExists(Player anotherPlayer) {
        boolean thereIsOne = false;
	for(int index = 0; index < players.size() && !thereIsOne; index++) {
		if (model.get(index).equals(anotherPlayer))
                    thereIsOne = true;
	}
	return thereIsOne;  

    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       searchPlayer
     * Description  Helper method to take a String, name, as argument and return
     *              the Player object if found. If not found, shows a message.
     *              Calls Validation.flatten() to remove accent marks
     * Date         3/9/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       anotherPlayer Player
     * @return      Player
     * @see         Validation
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private Player searchPlayer(String name) {
        if (name != null && !name.isEmpty()) {
            name = Validation.flatten(name.toLowerCase());
            int index = 0;
            for (Player player : players) {
                if (Validation.flatten(player.getName().toLowerCase()).contains(name)) {
                    playersJList.setSelectedIndex(index);
                    playersJList.ensureIndexIsVisible(index); 
                    return player;
                }
                index++;
            }
            JOptionPane.showMessageDialog(null, "Player " + name + " not found", 
                    "Search result", JOptionPane.WARNING_MESSAGE);
        }
        return null;
        }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		main()
    * Description       Create and set visible an instance of the TwoCardsGUI.	
    * @param		args String[]
    * @author           <i>Arthur Rahman</i>
    * Date              3/3/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        Splash mySplash = new Splash(5000);
        mySplash.showSplash();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TwoCardsGUI().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutJMenuItem;
    private javax.swing.JMenuItem addJMenuItem;
    private javax.swing.JLabel betJLabel;
    private javax.swing.JTextField betJTextField;
    private javax.swing.JLabel cardJLabel1;
    private javax.swing.JLabel cardJLabel2;
    private javax.swing.JButton clearJButton;
    private javax.swing.JMenu databaseJMenu;
    private javax.swing.JMenuItem deleteJMenuItem;
    private javax.swing.JMenuItem detailsJMenuItem;
    private javax.swing.JButton drawJButton;
    private javax.swing.JMenuItem editJMenuItem;
    private javax.swing.JMenuItem exitJMenuItem;
    private javax.swing.JMenu fileJMenu;
    private javax.swing.JMenuBar fileJMenuBar;
    private javax.swing.JMenu helpJMenu;
    private javax.swing.JScrollPane instructionsJScrollPane;
    private javax.swing.JTextArea instructionsJTextArea;
    private javax.swing.JMenuItem newJMenuItem;
    private javax.swing.JList<String> playersJList;
    private javax.swing.JScrollPane playersJScrollPane;
    private javax.swing.JMenuItem printFormJMenuItem;
    private javax.swing.JMenuItem printJMenuItem;
    private javax.swing.JCheckBox replacementJCheckBox;
    private javax.swing.JScrollPane resultsJScrollPane;
    private javax.swing.JTextArea resultsJTextArea;
    private javax.swing.JMenuItem saveJMenuItem;
    private javax.swing.JMenuItem searchJMenuItem;
    private javax.swing.JLabel titleJLabel;
    // End of variables declaration//GEN-END:variables

    
}
