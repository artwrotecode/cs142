package TwoCards;

import java.util.ArrayList;
import java.util.Random;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        DeckOfCards.java
 * Description  Class that represents a full deck of cards and a private
 *              ArrayList of integers that identify each card.
 * Project      Project 3--Two Cards Game
 * Platform     JDK 25.0.1; NetBeans IDE 28; Mac OS X version 26.3 
 * Course       CS 142
 * Hours        1 hour
 * Date         2/24/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1%
 * @see         java.text.DecimalFormat
 *</pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class DeckOfCards {
    private final int FULL_DECK_SIZE = 52;
    private ArrayList<Integer> cardDeck = new ArrayList();
    private Random myRandom = new Random();
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  DeckOfCards()-default constructor
    * Description  Create an instance of DeckOfCards with default values
    * Date         3/9/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public DeckOfCards() {
        for (int i = 1; i <= FULL_DECK_SIZE; i++)
            cardDeck.add(i);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method		getRandomCard()
    * Description       Method to generate a random index 0-51 to display a
    *                   random card in the cardDeck ArrayList. If replacement is
    *                   true, the first card drawn is not removed from the deck.
    *                   Otherwise, the card is removed from the deck so second 
    *                   draw is unique.
    * @param            replacement Boolean
    * @return           int -- index of randomCard
    * @author           <i>Arthur Rahman</i>
    * Date              3/9/2026
    * History Log       
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public int getRandomCard(Boolean replacement) {
        int randomIndex = myRandom.nextInt(cardDeck.size());
        int actualCard = cardDeck.get(randomIndex);
        // only remove if replacement is not checked
        if (!replacement)
            cardDeck.remove(randomIndex);
        return actualCard;
    }
    
    
}
