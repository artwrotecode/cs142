package TwoCards;

import java.text.DecimalFormat;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        Player.java
 * Description  Player class that is a subclass of the Person class (exhibiting 
 *              inheritance, “is-a” relationship) that implements the Comparable
 *              interface. Represents a player of a card game. Private instance 
 *              variables balance (each player starts with an initial balance
 *              of $1,000)
 * Project      Project 3--Two Cards Game
 * Platform     JDK 25.0.1; NetBeans IDE 28; Mac OS X version 26.3 
 * Course       CS 142
 * Hours        1 hour
 * Date         2/24/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1%
 * @see         Person
 * @see         java.text.DecimalFormat
 *</pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class Player extends Person implements Comparable<Player> {
    private double balance;
    private DecimalFormat dollars = new DecimalFormat("$,##0.00");
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  Player()-default constructor
    * Description  Create an instance of Player with default values. Implicit
    *              call to Person() default const.
    * Date         2/24/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Player() {
        this(0.0);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  Player()-one-arg constructor
    * Description  Create an instance of Player with given balance. Implicit
    *              call to Person() default const.
    * @param       balance double
    * Date         2/24/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Player(double balance) {
        this.balance = balance;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  Player()-overloaded constructor
    * Description  Create an instance of Player with given parameters.
    * @param       balance double
    * @param       name String
    * @param       age int
    * Date         2/24/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Player(double balance, String name, int age) {
        super(name, age);
        this.balance = balance;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  Player()-copy constructor
    * Description  Create an instance of Player, copying the parameters from
    *              anotherPlayer
    * @param       anotherPlayer Player
    * Date         2/24/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Player(Player anotherPlayer) {
        this.name = anotherPlayer.name;
        this.age = anotherPlayer.age;
        this.balance = anotherPlayer.balance;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        getBalance()
    * Description   Getter method to access balance of Player	
    * @return       balance double
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public double getBalance() {
        return balance;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        setBalance()
    * Description   Setter method to mutate balance of Player	
    * @param        balance double
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setBalance(double balance) {
        this.balance = balance;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        toString()
    * Description   Overridden toString method to return the Player's name as 
    *               String
    * @return       String--player's name
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public String toString() {
        return name;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        getFullDetails()
    * Description   Custom toString method to return the entire Player object
    *               as a String for the display method in Textfield
    * @return       String--player's name, age, balance 
    * @author       <i>Arthur Rahman</i>	
    * Date          3/9/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String getFullDetails() {
    return "Player name: " + name + "\nAge: " + age +
           "\nBalance: " + dollars.format(balance);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        toCSV()
    * Description   Custom toString method to return the entire Player object
    *               as a comma-delimitted string for saving to file.
    * @return       String
    * @author       <i>Arthur Rahman</i>	
    * Date          3/9/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String toCSV() {
        return name + "," + age + "," + balance;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        hashCode()
    * Description   Overridden hashCode method to return the Player's fields
    *               as a unique hash
    * @return       int
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public int hashCode() {
        return super.hashCode();
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        equals()
    * Description   Overridden equals method to check if one instance of Player
    *               is the same as another. Checks players by name (and if names
    *               are equal, then by age). The Person class does this already.
    * @param        obj Object
    * @return       boolean
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        compareTo()
    * Description   Required overridden compareTo() method for comparison of two 
    *               players by name (and if names are equal, then by age)
    * @param        o Player
    * @return       int
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public int compareTo(Player o) {
        // 1. Primary check: Name
        int nameCompare = this.getName().compareToIgnoreCase(o.getName());
    
        if (nameCompare != 0) {
            return nameCompare; // Names are different, so we're done
        }
    
        // 2. Secondary check: Names were equal, so check Age
        return Integer.compare(this.getAge(), o.getAge());
    }
    
}
