package TwoCards;

import java.util.Objects;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *<pre>
 * Class        Person.java
 * Description  Abstract Person class with protected instance variables name 
 *              (String) and age (int)
 * Project      Project 3--Two Cards Game
 * Platform     JDK 25.0.1; NetBeans IDE 28; Mac OS X version 26.3 
 * Course       CS 142
 * Hours        1 hour
 * Date         2/24/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1%
 *</pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public abstract class Person {
    protected String name;
    protected int age;
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  Person()-overloaded constructor
    * Description  Create an instance of Person with given arguments and
    *              set properties
    * @param       name String
    * @param       age  int
    * Date         2/24/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
   /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Constructor  Person()-default constructor
    * Description  Create an instance of Person with default values
    * Date         2/24/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/  
    public Person() {
        this("",0);
    }
   /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        getName()
    * Description   Getter method to access name of Person	
    * @return       name String
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String getName() {
        return name;
    }
   /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        setName()
    * Description   Setter method to mutate name of Person	
    * @param        name String
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setName(String name) {
        this.name = name;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        getAge()
    * Description   Getter method to access age of Person	
    * @return       age int
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public int getAge() {
        return age;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        setAge()
    * Description   Setter method to mutate age of Person	
    * @param        age int
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setAge(int age) {
        this.age = age;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        toString()
    * Description   Overridden toString method to return Person object fields
    *               as a String
    * @return       String
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", age=" + age + '}';
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        hashCode()
    * Description   Overridden hashCode method to return unique hash for an
    *               instance of a Person
    * @return       int
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + Objects.hashCode(this.name);
        hash = 61 * hash + this.age;
        return hash;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        equals()
    * Description   Overridden equals method to check if one instance of a
    *               Person object is the same as another. First checks if 
    *               they share same name, then checks if they share same age.
    * @return       boolean
    * @author       <i>Arthur Rahman</i>	
    * Date          2/24/2026
    * History Log   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return this.age == other.age;
    }
    
    
    
}
