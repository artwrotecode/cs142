package Horses;

import java.util.Objects;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <pre>
 * Class        Horse.java
 * Description  A class that represents a horse object, a subclass of
 *              Animal. Three private instance variables: weight (double), 
 *              isRacing (boolean to indicated whether the horse is a race horse 
 *              or not) and description (String).
 * Project      Project 2--Horse Breed Quiz
 * Platform     jdk 25.0.1; NetBeans IDE 28; Mac OS X version 26.2
 * Course       CS 142
 * Hours        1 hour
 * Date         2/10/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1% 
 * @see     	Animal
 * </pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class Horse extends Animal implements Comparable<Horse>{
    private double weight;
    private boolean isRacing;
    private String description;
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  Horse()-default constructor
     * Description  Creates a horse object with default values
     * Date         2/10/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Horse() {
        this("",0,0.0, false, "");
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  Horse()-overloaded copy constructor
     * Description  Copies an instance of a horse using it's attributes as
     *              arguments. Calls super constructor of Animal to set breed and age.
     * @param       anotherHorse Horse
     * Date         2/10/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Horse(Horse anotherHorse) {
        super(anotherHorse);
        this.weight = anotherHorse.weight;
        this.isRacing = anotherHorse.isRacing;
        this.description = anotherHorse.description;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  Horse()-overloaded constructor
     * Description  Creates an instance of a horse with provided arguments. Calls
     *              super constructor of Animal to set breed and age.
     * @param       weight double
     * @param       isRacing boolean
     * @param       description String
     * @param       breed String
     * @param       age int
     * Date         2/10/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Horse(String breed, int age, double weight, boolean isRacing, String description) {
        super(breed, age);
        this.weight = weight;
        this.isRacing = isRacing;
        this.description = description;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       getWeight()
     * Description  Getter accessor method to return the weight of the horse 
     * @return      weight double
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public double getWeight() {
        return weight;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       setWeight()
     * Description  Setter mutator method to set the weight of the horse 
     * @param       weight double
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setWeight(double weight) {
        this.weight = weight;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       isIsRacing()
     * Description  Getter accessor method to return wether the horse is racing
     * @return      isRacing boolean
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public boolean isIsRacing() {
        return isRacing;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       setIsRacing()
     * Description  Setter mutator method to set wether the horse is racing
     * @param       isRacing boolean
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setIsRacing(boolean isRacing) {
        this.isRacing = isRacing;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       getDescription()
     * Description  Getter accessor method to return description of the horse
     * @return      description String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String getDescription() {
        return description;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       setDescription()
     * Description  Setter mutator method to set description of the horse
     * @param       description String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setDescription(String description) {
        this.description = description;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       hashCode()
     * Description  Overridden hash code method to generate unique hashCode for
     *              a horse object
     * @return      hash int
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public int hashCode() {
        int hash = super.hashCode();
        // Add the Horse-specific fields using the same multiplier
        hash = 89 * hash + (this.isRacing ? 1 : 0);
        long weightBits = Double.doubleToLongBits(this.weight);
        hash = 89 * hash + (int) (weightBits ^ (weightBits >>> 32));
        return hash;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       equals()
     * Description  Overridden equals method to see if another horse object is
     *              the same as another horse object.It uses super.equals(obj) 
     *              to verify the breed and age first. Then checks if the horse
     *              is the same isRacing, and if they are the same checks weight.
     * @param       obj Object
     * @return      boolean
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        
        final Horse other = (Horse) obj;
        
        if (this.isRacing != other.isRacing) return false;

        // Use Double.compare to handle precision/NaN safely
        return Double.compare(this.weight, other.weight) == 0;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       toString()
     * Description  Overridden toString method to return the attributes of the
     *              horse as a string
     * @return      Horse String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public String toString() {
        return "Horse: " + breed + 
                "\nAverage Age: " + age + 
                "\nAverage Weight: " + weight + 
                "\nIs Race Horse: " + isRacing + 
                "\nDescription: " + description;
    }
    
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       compareTo()
     * Description  Overridden compareTo method, to check if one horse is heavier
     *              than another. Returns 1 if this horse is larger, returns -1 
     *              if it is smaller, and returns 0 if they are the same. If weight
     *              is the same, he compares age, if age is same he compares
     *              strings. The breed, isRacing is compared to ensure 
     *              consistency with equals
     * @return      Horse String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public int compareTo(Horse other) {
        int weightCompare = Double.compare(this.weight, other.weight);
        if (weightCompare != 0) return weightCompare;

        int ageCompare = Integer.compare(this.age, other.age);
        if (ageCompare != 0) return ageCompare;

        int breedCompare = this.breed.compareTo(other.breed);
        if (breedCompare != 0) return breedCompare;

        return Boolean.compare(this.isRacing, other.isRacing);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       toPipeDelimited()
     * Description  Helper method for saveHorses() method in HorseQuizGUI.
     *              Returns horse as pipe-delimited string for saving to the 
     *              external file. 
     * @return      Horse String
     * Date         2/17/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String toPipeDelimited() {
    return breed + "|" + age + "|" + weight + "|" + isRacing + "|" + description;
    }   
    
    
    
    
    
    
    
}
