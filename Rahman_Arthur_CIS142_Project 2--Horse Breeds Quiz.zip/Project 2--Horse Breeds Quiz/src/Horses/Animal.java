package Horses;

import java.util.Objects;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <pre>
 * Class        Animal.java
 * Description  An abstract class that serves as a superclass for various animals
 *              (like horses).
 * Project      Project 2--Horse Breed Quiz
 * Platform     jdk 25.0.1; NetBeans IDE 28; Mac OS X version 26.2
 * Course       CS 142
 * Hours        1 hour
 * Date         2/10/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1% 
 * </pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public abstract class  Animal {
    protected String breed;
    protected int age;
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  Animal()-default constructor
     * Description  Create an instance of the Animal using default values
     * Date         2/10/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Animal() {
        this("",0);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  Animal()-overloaded copy constructor
     * Description  Creates a copy of anotherAnimal object using the same values
     *              as its instance fields.
     * @param       anotherAnimal Animal
     * Date         2/10/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Animal(Animal anotherAnimal) {
        this.breed = anotherAnimal.breed;
        this.age = anotherAnimal.age;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  Animal()-overloaded constructor
     * Description  Creates an instance of an animal with provided arguments
     * Date         2/10/2025
     * @param       breed String
     * @param       age int
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    public Animal(String breed, int age) {
        this.breed = breed;
        this.age = age;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       getBreed()
     * Description  Getter accessor method to return the breed of the animal 
     * @return      breed String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public String getBreed() {
        return breed;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       setBreed()
     * Description  Setter mutator method to set the breed of the animal 
     * @param       breed String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setBreed(String breed) {
        this.breed = breed;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       getAge()
     * Description  Getter accessor method to return the age of the animal 
     * @return      age int
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public int getAge() {
        return age;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       setAge()
     * Description  Setter mutator method to set the age of the animal 
     * @param       age int
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void setAge(int age) {
        this.age = age;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       hashCode()
     * Description  method to return the unique hash code of an animal object
     * @return      hash int
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.breed);
        hash = 89 * hash + this.age;
        return hash;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       equals()
     * Description  method to check if one animal object is the same as another.
     *              compares two Horses first by names and if equal in names, then by age.
     * @param       obj Object
     * @return      boolean
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animal other = (Animal) obj;
        return this.age == other.age && Objects.equals(this.breed, other.breed);
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       toString()
     * Description  method to return the object's attributes as a String     
     * @return      Animal breed,age-- String
     * Date         2/10/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public String toString() {
        return "Animal{" + "breed=" + breed + ", age=" + age + '}';
    }
    
    
    
    
}
