package Horses;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <pre>
 * Class        HorseQuizGUI.java
 * Description  A class representing the GUI used in a horse breed quiz 
 *              application. The application starts when the user enters a valid 
 *              number of questions for the quiz (bound by the number of Horses 
 *              in the database). The program then displays a random picture of 
 *              a Horse and asks the user to select the name of the breed to 
 *              which the Horse belongs from a horsesJComboBox. Correct or 
 *              incorrect is displayed along with a count to notify the user of 
 *              their answer. The user than selects next Horse picture and the 
 *              quiz continues until all questions are answered.
 * Project      Project 2--Horse Breed Quiz
 * Platform     jdk 25.0.1; NetBeans IDE 28; Mac OS X version 26.2
 * Course       CS 142
 * Hours        5 hours
 * Date         2/5/2026
 * History Log  
 * @author	<i>Arthur Rahman</i>
 * @version 	%1% 
 * @see     	javax.swing.JFrame
 * @see         java.awt.Toolkit 
 * @see         javax.swing.DefaultListModel
 * </pre>
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class HorseQuizGUI extends javax.swing.JFrame
{
    // class instance variables
    private String fileName = "src/Data/Horses.txt";
    private String horseBreed = "";
    private int count = 0;
    private ArrayList<Horse> horses = new ArrayList();
    private ArrayList<Boolean> horsesUsed = new ArrayList();
    //numbersUsed is optional substitute for the boolean horsesUsed
    private ArrayList<Integer> numbersUsed = new ArrayList();
    private int currentIndex = 0;
    private int countCorrect = 0;
    private int numberOfHorses = 0;
    private int numberOfQuestions = 0;
    private static int maxQuestions = 1;
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Constructor  HorseQuizGUI()-default constructor
     * Description  Create an instance of the GUI form, set the default
     *              JButton to be submitJButton, set icon image, center form,
     *              read horses from external file.
     * Date         2/5/2025
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/  
    public HorseQuizGUI()
    {
        initComponents();
        // set the submit JButton as default 
        this.getRootPane().setDefaultButton(submitJButton);
        // set icon picture on the title
        this.setIconImage(Toolkit.getDefaultToolkit().getImage
        ("src/Images/icon.jpg"));
        // center form
        this.setLocationRelativeTo(null);
        // read students and signs from file
        readFromFile(fileName);  // instantiates the horses array
        
//        displayHorse();              // display first horse randomly
        nextJButton.setEnabled(false);
        playJButton.setEnabled(false);
        submitJButton.setEnabled(false);
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       readFromFile
     * Description  Reads horses from a file Horses.txt and fill horsesJComboBox.  
     * Date         2/5/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       fileName String
     * @see         java.io.File
     * @see         java.util.Scanner
     * @see         java.util.StringTokenizer
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void readFromFile(String fileName)
    {   
        numberOfHorses = 0;
        horsesJComboBox.removeAllItems();
        horses.clear();
        try {
            Scanner input = new Scanner(new File(fileName));
            String line = "";
            Horse horse = null;
            StringTokenizer token = null;
            // read from File and count how many there are to size the arrays
            while (input.hasNextLine()) {
                line = input.nextLine();
                horse = new Horse();
                token = new StringTokenizer(line, "|");
                while (token.hasMoreElements()) {
                    horse.setBreed(token.nextToken());
                    horse.setAge(Integer.parseInt(token.nextToken()));
                    horse.setWeight(Double.parseDouble(token.nextToken()));
                    horse.setIsRacing(Boolean.parseBoolean(token.nextToken()));
                    horse.setDescription(token.nextToken());                    
                }
                //add horse
                horses.add(horse);
                numberOfHorses++;
            }
            input.close();
            
            maxQuestions = numberOfHorses;
            questionsJTextField.setToolTipText("Enter an integer in the range [1, "
                                + maxQuestions + "].");
            // create parallel arrays
            horsesUsed = new ArrayList<Boolean>(numberOfHorses);
            numbersUsed = new ArrayList<Integer>(numberOfHorses);
            
            for (int i = 0; i < numberOfHorses; i++) {
                horsesUsed.add(false);
                numbersUsed.add(i);
            }
            selectionSort(horses);
            fillComboBox(horses);        // populate combobox
            horsesJComboBox.setEnabled(true);
        }
        catch (FileNotFoundException exp) {
            JOptionPane.showMessageDialog(null, fileName + "does not exist",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
            // Bring up JFileChooser to select file in current directory
            JFileChooser chooser = new JFileChooser("src/Data");
            // Filter only txt files
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "Txt Files", "txt");
            chooser.setFileFilter(filter);
            int choice = chooser.showOpenDialog(null);
            if (choice == JFileChooser.APPROVE_OPTION) {
                File chosenFile = chooser.getSelectedFile();
                fileName = "src/Data/" + chosenFile.getName();
                System.out.println("file = " + fileName);
                readFromFile(fileName);
            }
            else {
                System.exit(0);
            }
        }
        catch (Exception exp) {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
        
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       fillComboBox
     * Description  Fill signsJComboBox with horse names
     * Date         2/16/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       artists String[]
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @SuppressWarnings("unchecked")
    private void fillComboBox(ArrayList horses)
    {
       horsesJComboBox.removeAllItems();
       Horse horse = new Horse();
       for (int j = 0; j < horses.size(); j++) {
           horse = (Horse)horses.get(j);
           horsesJComboBox.addItem(horse.getBreed());
       }
    }

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       displayHorse
     * Description  Choose a random and unused horse from the ArrayList and display
     *              it in the horseJLabel.
     *              
     * Date         2/9/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @see         java.awt.Image
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void displayHorse()
    {
       currentIndex = getUniqueRandomNumber();
       horseBreed = horses.get(currentIndex).getBreed();
       // create the path for file
       String horsePath  = "src/Images/" + horseBreed + ".jpg";
       File horsesPicture = new File(horsePath);
       if (!horsesPicture.isFile())
           horsePath = "src/Images/default.jpg";
       // set the horseJLabel to display the horse
       ImageIcon icon = new ImageIcon(horsePath);
       Image img = icon.getImage();
       Image newImg = img.getScaledInstance(horseJLabel.getWidth(),
               horseJLabel.getHeight(), Image.SCALE_SMOOTH);
       ImageIcon newIcon = new ImageIcon(newImg);
       horseJLabel.setIcon(newIcon);
       horseJLabel.setToolTipText(horseBreed); // gives away answer
    } 
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       displayHorse--Overloaded
     * Description  Overloaded method to display image of horse scaled to size
     *              of JLabel with a given index.            
     * Date         2/17/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @see         java.awt.Image
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void displayHorse(int index)
    {
       horseBreed = horses.get(index).breed;
       // create the path for file
       String horsePath  = "src/Images/" + horseBreed + ".jpg";
       File horsesPicture = new File(horsePath);
       if (!horsesPicture.isFile())
           horsePath = "src/Images/default.jpg";
       // set the horseJLabel to display the horse
       ImageIcon icon = new ImageIcon(horsePath);
       Image img = icon.getImage();
       Image newImg = img.getScaledInstance(horseJLabel.getWidth(),
               horseJLabel.getHeight(), Image.SCALE_SMOOTH);
       ImageIcon newIcon = new ImageIcon(newImg);
       horseJLabel.setIcon(newIcon);
       horseJLabel.setToolTipText(horseBreed); // gives away answer
    } 
    
    

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       getUniqueRandomNumber
     * Description  Return an unused random number by a blind repetition of
     *              random generation and checking for unused horse
     * Date         2/9/2026
     * History Log  
     * @return      random int
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private int getUniqueRandomNumber()
    {
       Random generator = new Random();
       int randomNumber = 0;
       // generate random numbers until unused horse is found
       do {
           // generate a number between 0 and horses.length-1
           randomNumber = generator.nextInt(horses.size());
       } while (horsesUsed.get(randomNumber));
       
       // indicate that horse has been used
       horsesUsed.set(randomNumber, true);
       return randomNumber;
    } 
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       horseExists
     * Description  Determine if horse passed in parameter exits
     * Date         2/17/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       Horse anotherHorse
     * @return      true or false boolean
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private boolean horseExists(Horse anotherHorse) {
        boolean thereIsOne = false;
	for(int index = 0; index < horses.size() && !thereIsOne; index++) {
		if (horses.get(index).equals(anotherHorse))
                    thereIsOne = true;
	}
	return thereIsOne;  

    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       searchHorse()
    * Description  Search for a horse by name of breed and highlight if found
    * Date         2/17/2026   
    * History log 
    * @param       breed String
    * @author      <i>Arthur Rahman</i>
    * @return      Horse -- index of searched horse
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private Horse searchHorse(String breed) {
        int index = -1; // default horse not found
        if ((breed != null) && (breed.length() > 0)) {
            //Create a String array of horse names
            String[] horseArray = new String[horses.size()];
            for (int i = 0; i < horseArray.length; i++)
                horseArray[i] = horses.get(i).getBreed().toLowerCase();
            //Find index of horse
            index = linearSearch(horseArray, breed);
            if (index < 0) {
                JOptionPane.showMessageDialog(null, "Horse " + breed +
                        " not found", "Search result", JOptionPane.WARNING_MESSAGE);
                if (horses.size() > 0) {
                    horsesJComboBox.setSelectedIndex(0);
                }
                return null;
            }
            else {
                horsesJComboBox.setSelectedIndex(index);
                displayHorse(index);
                return horses.get(index);
            }
        }
        return null;
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       linearSearch
    * Description  Method to search horse by name using the linear search algorithm
    *              and to display its index if found and -1 if not found
    * Date         2/17/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       horseArray String[]
    * @param       horseName String
    * @return      index int
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private int linearSearch(String[] horseArray, String horseName) {
        int index = -1;
        boolean found = false;
        for (int i = 0; i < horseArray.length && !found; i++) {
            if (horseArray[i].toLowerCase().contains(horseName.toLowerCase())) {
                index = i;
                found = true;
            }
    }
        return index;
    }
    
    private void selectionSort(ArrayList<Horse> horses) {
        int min = 0;
        for (int i = 0; i < horses.size(); i++) {
            // Find the "smallest" name (A comes before Z)
            min = findMinimum(horses, i);

            // Swap
            Horse temp = horses.get(i);
            horses.set(i, horses.get(min));
            horses.set(min, temp);
        }
    }

    private int findMinimum(ArrayList<Horse> horses, int i) {
        int min = i;
        for (int j = i + 1; j < horses.size(); j++) {
            // compareTo returns < 0 if the string comes before the other string
            String nameJ = horses.get(j).getBreed();
            String nameMin = horses.get(min).getBreed();

            if (nameJ.compareToIgnoreCase(nameMin) < 0) {
                min = j;
            }
        }
        return min;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       saveHorses
    * Description  Method to save newly added horses to the external TXT file
    * Date         2/17/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       fileName String
    * @see         java.io.PrintWriter
    * @see         java.io.FileWriter
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void saveHorses(String fileName) {
        try (PrintWriter out = new PrintWriter(new FileWriter(fileName))) {
        for (Horse h : horses) {
            out.println(h.toPipeDelimited());
        }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, fileName + "not saved",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        quizJLabel = new javax.swing.JLabel();
        horseJLabel = new javax.swing.JLabel();
        controlJPanel = new javax.swing.JPanel();
        submitJButton = new javax.swing.JButton();
        nextJButton = new javax.swing.JButton();
        playJButton = new javax.swing.JButton();
        selectJPanel = new javax.swing.JPanel();
        selectJLabel = new javax.swing.JLabel();
        horsesJComboBox = new javax.swing.JComboBox();
        resultJLabel = new javax.swing.JLabel();
        questionJLabel = new javax.swing.JLabel();
        questionsJTextField = new javax.swing.JTextField();
        horsesJMenuBar = new javax.swing.JMenuBar();
        fileJMenu = new javax.swing.JMenu();
        newJMenuItem = new javax.swing.JMenuItem();
        clearJMenuItem = new javax.swing.JMenuItem();
        printFormJMenuItem = new javax.swing.JMenuItem();
        printDetailsJMenuItem = new javax.swing.JMenuItem();
        fileJSeparator = new javax.swing.JPopupMenu.Separator();
        exitJMenuItem = new javax.swing.JMenuItem();
        actionJMenu = new javax.swing.JMenu();
        addJMenuItem = new javax.swing.JMenuItem();
        editJMenuItem = new javax.swing.JMenuItem();
        deleteJMenuItem = new javax.swing.JMenuItem();
        searchJMenuItem = new javax.swing.JMenuItem();
        detailsJMenuItem = new javax.swing.JMenuItem();
        helpJMenu = new javax.swing.JMenu();
        aboutJMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Horse Breeds Quiz");
        setResizable(false);

        quizJLabel.setFont(new java.awt.Font("Tahoma", 3, 26)); // NOI18N
        quizJLabel.setForeground(new java.awt.Color(51, 51, 0));
        quizJLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icon.png"))); // NOI18N
        quizJLabel.setText("Horse Breeds Quiz");

        horseJLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/default.jpg"))); // NOI18N
        horseJLabel.setFocusable(false);

        controlJPanel.setLayout(new java.awt.GridLayout(3, 1, 3, 5));

        submitJButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        submitJButton.setMnemonic('S');
        submitJButton.setText("Submit");
        submitJButton.setToolTipText("Click to submit your answer");
        submitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitJButtonActionPerformed(evt);
            }
        });
        controlJPanel.add(submitJButton);

        nextJButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nextJButton.setMnemonic('N');
        nextJButton.setText("Next Horse");
        nextJButton.setToolTipText("Click to see next horse");
        nextJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextJButtonActionPerformed(evt);
            }
        });
        controlJPanel.add(nextJButton);

        playJButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        playJButton.setMnemonic('P');
        playJButton.setText("Play Again");
        playJButton.setToolTipText("Play all over again!");
        playJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playJButtonActionPerformed(evt);
            }
        });
        controlJPanel.add(playJButton);

        selectJPanel.setLayout(new java.awt.GridLayout(3, 1, 3, 5));

        selectJLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        selectJLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        selectJLabel.setText("Select Horse Breed:");
        selectJLabel.setToolTipText("");
        selectJLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        selectJPanel.add(selectJLabel);

        horsesJComboBox.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        horsesJComboBox.setToolTipText("Select horse breed to match image");
        selectJPanel.add(horsesJComboBox);

        resultJLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        resultJLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        resultJLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        resultJLabel.setPreferredSize(new java.awt.Dimension(3, 3));
        selectJPanel.add(resultJLabel);

        questionJLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        questionJLabel.setText("Questions:");

        questionsJTextField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        questionsJTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                questionsJTextFieldActionPerformed(evt);
            }
        });
        questionsJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                questionsJTextFieldKeyTyped(evt);
            }
        });

        fileJMenu.setMnemonic('F');
        fileJMenu.setText("File");
        fileJMenu.setToolTipText("New, Clear, Print, Exit");

        newJMenuItem.setMnemonic('N');
        newJMenuItem.setText("New");
        newJMenuItem.setToolTipText("Open a new set of horses");
        newJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(newJMenuItem);

        clearJMenuItem.setMnemonic('C');
        clearJMenuItem.setText("Clear");
        clearJMenuItem.setToolTipText("Restore GUI to original state");
        clearJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(clearJMenuItem);

        printFormJMenuItem.setMnemonic('P');
        printFormJMenuItem.setText("Print Form");
        printFormJMenuItem.setToolTipText("Print Form as GUI");
        printFormJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printFormJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printFormJMenuItem);

        printDetailsJMenuItem.setMnemonic('H');
        printDetailsJMenuItem.setText("Print Horse Details");
        printDetailsJMenuItem.setToolTipText("Print individual horse details");
        printDetailsJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printDetailsJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printDetailsJMenuItem);
        fileJMenu.add(fileJSeparator);

        exitJMenuItem.setMnemonic('X');
        exitJMenuItem.setText("Exit");
        exitJMenuItem.setToolTipText("End application");
        exitJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(exitJMenuItem);

        horsesJMenuBar.add(fileJMenu);

        actionJMenu.setMnemonic('b');
        actionJMenu.setText("Database Operations");
        actionJMenu.setToolTipText("Add, Edit, Delete, Search, and Details");

        addJMenuItem.setMnemonic('A');
        addJMenuItem.setText("Add");
        addJMenuItem.setToolTipText("Add a new horse to database");
        addJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(addJMenuItem);

        editJMenuItem.setMnemonic('E');
        editJMenuItem.setText("Edit");
        editJMenuItem.setToolTipText("Edit selected horse details");
        editJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(editJMenuItem);

        deleteJMenuItem.setMnemonic('D');
        deleteJMenuItem.setText("Delete");
        deleteJMenuItem.setToolTipText("Delete selected horse from database");
        deleteJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(deleteJMenuItem);

        searchJMenuItem.setMnemonic('S');
        searchJMenuItem.setText("Search");
        searchJMenuItem.setToolTipText("Search for a horse (resets quiz)");
        searchJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(searchJMenuItem);

        detailsJMenuItem.setMnemonic('t');
        detailsJMenuItem.setText("Details");
        detailsJMenuItem.setToolTipText("Display information about the shown horse");
        detailsJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailsJMenuItemActionPerformed(evt);
            }
        });
        actionJMenu.add(detailsJMenuItem);

        horsesJMenuBar.add(actionJMenu);

        helpJMenu.setMnemonic('H');
        helpJMenu.setText("Help");
        helpJMenu.setToolTipText("About form");

        aboutJMenuItem.setMnemonic('A');
        aboutJMenuItem.setText("About");
        aboutJMenuItem.setToolTipText("Show about form");
        aboutJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutJMenuItemActionPerformed(evt);
            }
        });
        helpJMenu.add(aboutJMenuItem);

        horsesJMenuBar.add(helpJMenu);

        setJMenuBar(horsesJMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(horseJLabel)
                    .addComponent(quizJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(selectJPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(questionJLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(questionsJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(controlJPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quizJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(questionJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(questionsJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(selectJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(controlJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(horseJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       submitJButtonActionPerformed
     * Description  Event handler to check if the user's answer is correct. The
     *              correct answer is held in class instance variable 
     *              currentIndex.
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void submitJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitJButtonActionPerformed
       count++;
       detailsJMenuItem.setEnabled(true);
       printDetailsJMenuItem.setEnabled(true);
       horsesJComboBox.setEnabled(false);
       if (horsesJComboBox.getSelectedIndex() == currentIndex) {
           countCorrect++;
           resultJLabel.setText("Correct! " + countCorrect + "/" + count);
       }
       else { // if an incorrect answer is give
           resultJLabel.setText("Incorrect! " + countCorrect + "/" + count);
       }
       // inform user if quiz is over and enable/disable appropriate buttons
       if (count == numberOfQuestions) {
           resultJLabel.setText(countCorrect + "/" + numberOfQuestions + " Correct! Quiz finished.");
           nextJButton.setEnabled(false);
           submitJButton.setEnabled(false);
           playJButton.setEnabled(true);
           horsesJComboBox.setEnabled(false);
       }
       else {       // if less than # questions have been displayed
           nextJButton.setEnabled(true);
           submitJButton.setEnabled(false);
           playJButton.setEnabled(false);
       }
       
       
           
    }//GEN-LAST:event_submitJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * <pre>
     * Method       nextJButtonActionPerformed
     * Description  Event handler to select next unused horse randomly by 
     *              calling the displayHorse() method.
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void nextJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextJButtonActionPerformed
        displayHorse();        // display next horse
        // reset GUI components to initial states
        resultJLabel.setText("");
        horsesJComboBox.setEnabled(true);
        horsesJComboBox.setSelectedIndex(0);
        submitJButton.setEnabled(true);
        nextJButton.setEnabled(false);
        detailsJMenuItem.setEnabled(false);
    }//GEN-LAST:event_nextJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       playJButtonActionPerformed
     * Description  Event handler to start the game all over again. Calls the
     *              clearJMenuItemActionPerformed evt handler to reset GUI.
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void playJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playJButtonActionPerformed
        clearJMenuItemActionPerformed(evt);
    }//GEN-LAST:event_playJButtonActionPerformed

   /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       aboutJMenuItemActionPerformed()
     * Description  Create an About form and show it. 
     * Date         2/5/2026
     * History Log  
    *</pre>
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void aboutJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_aboutJMenuItemActionPerformed
    {//GEN-HEADEREND:event_aboutJMenuItemActionPerformed
        About aboutWindow = new About(this, true);
        aboutWindow.setVisible(true);
    }//GEN-LAST:event_aboutJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       exitJMenuItemActionPerformed()
     * Description  Close application. 
     * Date         2/5/2026
     * History Log   
     *</pre>
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void exitJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitJMenuItemActionPerformed
    {//GEN-HEADEREND:event_exitJMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       printJMenuItemActionPerformed
     * Description  Event handler to print the form as a GUI. Calls the 
     *              PrintUtilities printComponent method.
     * Date         2/5/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void printFormJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printFormJMenuItemActionPerformed
        PrintUtilities.printComponent(this);
    }//GEN-LAST:event_printFormJMenuItemActionPerformed

   /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       questionsJTextFieldKeyTyped
     * Description  Event handler to validate the user input for amt of questions
     *              and call the displayHorse() method
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void questionsJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_questionsJTextFieldKeyTyped
        char ch = evt.getKeyChar();
        if (!Character.isDigit(ch) && ch != '\b') {
            evt.consume(); // Ignore the character
            Toolkit.getDefaultToolkit().beep();
            //JOptionPane.showMessageDialog(null, "Please enter digits only.");
            return;
        }
        if (ch == '\n') { // Enter key
            displayHorse();
        }
    }//GEN-LAST:event_questionsJTextFieldKeyTyped
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       questionsJTextFieldActionPerformed
     * Description  Event handler to validate the user input for amt of questions
     *              and call the displayHorse() method
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void questionsJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_questionsJTextFieldActionPerformed
        try {
            if (!Validation.isInteger( questionsJTextField.getText(), 1, maxQuestions))
                throw new NumberFormatException();
            numberOfQuestions = Integer.parseInt(questionsJTextField.getText().trim());
            questionsJTextField.setEnabled(false);
            horsesJComboBox.setEnabled(true);
            submitJButton.setEnabled(true);
            displayHorse();
            submitJButton.setEnabled(true);
            newJMenuItem.setEnabled(false);
            printDetailsJMenuItem.setEnabled(false);
            addJMenuItem.setEnabled(false);
            editJMenuItem.setEnabled(false);
            deleteJMenuItem.setEnabled(false);
            searchJMenuItem.setEnabled(false);
            detailsJMenuItem.setEnabled(false);
        }
        catch (NumberFormatException exp) {
            JOptionPane.showMessageDialog(null, "Must be an integer in " +
                    "the range [1, " + maxQuestions + "].", "Input Errror",
                    JOptionPane.WARNING_MESSAGE);
            questionsJTextField.requestFocus();
            questionsJTextField.selectAll();
        }
    }//GEN-LAST:event_questionsJTextFieldActionPerformed

//GEN-FIRST:event_newSignsJMenuItemActionPerformed
 
//GEN-LAST:event_newSignsJMenuItemActionPerformed
     /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       clearJMenuItemActionPerformed
     * Description  Event handler to reset the GUI to its original state, and
     *              to reset question count and boolean array horsesUsed
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void clearJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearJMenuItemActionPerformed
        // Start game all over
        countCorrect = 0;
        count = 0;
        questionsJTextField.setText("");
        resultJLabel.setText("");
        submitJButton.setEnabled(false);
        nextJButton.setEnabled(false);
        questionsJTextField.setEnabled(true);
        playJButton.setEnabled(false);
        horsesJComboBox.setEnabled(true);
        horsesJComboBox.setSelectedIndex(0);
        questionsJTextField.requestFocus();
        newJMenuItem.setEnabled(true);
        printDetailsJMenuItem.setEnabled(true);
        addJMenuItem.setEnabled(true);
        editJMenuItem.setEnabled(true);
        deleteJMenuItem.setEnabled(true);
        searchJMenuItem.setEnabled(true);
        detailsJMenuItem.setEnabled(true);
        horseJLabel.setIcon(new ImageIcon("src/Images/default.jpg"));
        
        // reset boolean array to false and number arrays to 0's
        for (int i = 0; i < horsesUsed.size(); i++) {
            horsesUsed.set(i, false);
            numbersUsed.set(i, 0);
        }
    }//GEN-LAST:event_clearJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       printDetailsJMenuItemActionPerformed
     * Description  Event handler for printDetailsJMenuItem to create a JTextArea 
     *              and populate with selected horse information and print it
     * Date         2/16/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
     * @see         java.awt.print.PrinterException
     * @see         javax.swing.JTextArea
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void printDetailsJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printDetailsJMenuItemActionPerformed

        int indexToShow;
        if (count > 0) {
            indexToShow = currentIndex;
        } else {
            indexToShow = horsesJComboBox.getSelectedIndex();
        }
        JTextArea printHorse = new JTextArea();
        if(indexToShow >= 0) {
            try {
                Horse temp = new Horse(horses.get(indexToShow));
                String output = temp.toString();
                printHorse.setText(output);
                printHorse.print();
                System.out.println(output);  // print line for troubleshooting
            }
            catch (PrinterException ex) {
                JOptionPane.showMessageDialog(null, "Horse not Printed",
                        "Print Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_printDetailsJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       addJMenuItemActionPerformed
     * Description  Event handler for adding a Horse by invoking the AddHorse form.
     *              No empty or duplicate Horse is added. The new Horse is added to
     *              the JComboBox and saved in the Horse.txt file
     * Date         2/16/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void addJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJMenuItemActionPerformed
        // Add new Horse
        try {
            // Create and display a new AddDialog
            AddHorse addHorse = new AddHorse();
            addHorse.setVisible(true);
            
            // The modal dialog takes focus, upon regaining focus:
            Horse newHorse = addHorse.getHorse();
            if (newHorse != null && !horseExists(newHorse)) 
            {
                // add the new horse to the database
                horses.add(newHorse);                
                // save new horse to file
                saveHorses(fileName);
                // read appended file to update variables
                readFromFile(fileName);
                searchHorse(newHorse.breed);      
            }
            else {
                horsesJComboBox.setVisible(true);
                horsesJComboBox.setSelectedIndex(0);
            }
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Horse not added",
                    "Add Horse Error", JOptionPane.WARNING_MESSAGE);
            horsesJComboBox.setVisible(true);
            horsesJComboBox.setSelectedIndex(0);
        }
    }//GEN-LAST:event_addJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       editJMenuItemActionPerformed
     * Description  Event handler for editing a Horse by invoking the EditHorse 
     *              form. The updated Horse is added to the JComboBox and saved 
     *              in the Horse.txt file
     * Date         2/16/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void editJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editJMenuItemActionPerformed
        try {
            // get name of selected horse
            String horseName = horsesJComboBox.getSelectedItem().toString();
            
            // create a temp Horse to populate fields of form
            Horse horseToEdit = new Horse(searchHorse(horseName));
            int index = horsesJComboBox.getSelectedIndex();
            
            // pass Horse info to EditHorse constructor and view edit form
            EditHorse editedHorse = new EditHorse(horseToEdit);
            editedHorse.setVisible(true);
            
            // get edited horse and add to array list
            if (editedHorse.getHorse() != null) {
                // remove old horse from ArrayList
                horses.remove(index);
                // add edited horse to ArrayList
                horses.add(editedHorse.getHorse());
                saveHorses(fileName);
                readFromFile(fileName);
                searchHorse(editedHorse.getHorse().getBreed());
            }
            
        }
        catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "Horse not edited",
                    "Edit Horse Error", JOptionPane.WARNING_MESSAGE);
            horsesJComboBox.setVisible(true);
            horsesJComboBox.setSelectedIndex(0);
        }
    }//GEN-LAST:event_editJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       deleteJMenuItemActionPerformed
     * Description  Event handler for the deleteJMenuItem to delete the selected
     *              horse from the JComboBox and the database
     * Date         2/17/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void deleteJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteJMenuItemActionPerformed
        // Delete selected Horse, do nothing on Cancel
        try {
        int index = horsesJComboBox.getSelectedIndex();
        String name = horses.get(index).getBreed();
        int result = JOptionPane.showConfirmDialog(null, 
                "Are you sure you wish to delete " + name + "?", "Delete Horse",
                JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            index = horsesJComboBox.getSelectedIndex();
            horses.remove(index);
            saveHorses(fileName);
            readFromFile(fileName);
        }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Horse not deleted",
                    "Delete Horse Error", JOptionPane.WARNING_MESSAGE);
            horsesJComboBox.setVisible(true);
            horsesJComboBox.setSelectedIndex(0);
        }
    }//GEN-LAST:event_deleteJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method       searchJMenuItemActionPerformed
    * Description  Event handler for searchJMenuItem. It calls searchHorse() 
    *              method
    * Date         2/17/2026
    * History Log  
    * @author      <i>Arthur Rahman</i>
    * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void searchJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchJMenuItemActionPerformed
        String horseName = JOptionPane.showInputDialog("Enter breed of horse");
        // Safety check: Exit if the user clicked "Cancel" or left it blank
        if (horseName == null || horseName.trim().isEmpty()) {
            return; 
        }

        // Capture the result of the search
        Horse foundHorse = searchHorse(horseName);

        // If search failed, stop here to avoid using a 'null' horse
        if (foundHorse == null) {
            return;
        }
    }//GEN-LAST:event_searchJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       detailsJMenuItemActionPerformed
     * Description  Creates a new Detail JDialog object and passes the selected
     *              horse as an argument to show the horse's details.
     * Date         2/17/2026
     * History Log  
     * @author      <i>Arthur Rahman</i>
     * @param       evt javax.swing.event.ActionEvent
    *</pre>     
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void detailsJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailsJMenuItemActionPerformed
        Detail horseDetail;
        int indexToShow;
        if (count > 0) {
            indexToShow = currentIndex;
        } else {
            indexToShow = horsesJComboBox.getSelectedIndex();
        }
        // alternative: get name from JList and search for horse with that name
        if (indexToShow >= 0) {
            Horse targetHorse = new Horse(horses.get(indexToShow));
            horseDetail = new Detail(targetHorse);
            horseDetail.setVisible(true);
        }
    }//GEN-LAST:event_detailsJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>
     * Method       newJMenuItemActionPerformed
     * Description  Event handler for newJMenuItem to choose new set of horses
     *              from external txt file. 
     * Date         2/16/2026
     * History Log  
     * @param       evt ActionEvent
     * @author      <i>Arthur Rahman</i>
     *</pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void newJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newJMenuItemActionPerformed
        //Bring up JFileChooser to select file in curent directory
        JFileChooser chooser = new JFileChooser("src/Data");
        //Filter only txt files
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
        "Txt Files", "txt");
        chooser.setFileFilter(filter);
        int choice = chooser.showOpenDialog(null);
        if (choice == JFileChooser.APPROVE_OPTION) {
            //Clear existing horses ArrayList
            horses.clear();
            clearJMenuItemActionPerformed(evt);
            File chosenFile = chooser.getSelectedFile();
            String file = "src/Data/" + chosenFile.getName();
            
            // need to update fileName to save changes in correct file -- cannot be final
            fileName = file;
            System.out.println("file = " + file);
            readFromFile(file);
            
        }
        else   // weird I/O error
        {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_newJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
     * Method       main()
     * Description  Displays splash screen and the main HorseQuiz GUI form.
     * Date         2/7/2026    
     * History log 
     * @param       args are the command line strings
     * @author      <i>Arthur Rahman</i>
     *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static void main(String args[])
    {
        // Show splash screen
        Splash mySplash = new Splash(5000);     // duration = 4 seconds
        mySplash.showSplash();                  // show splash screen
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                HorseQuizGUI quiz = new HorseQuizGUI();                
                quiz.setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutJMenuItem;
    private javax.swing.JMenu actionJMenu;
    private javax.swing.JMenuItem addJMenuItem;
    private javax.swing.JMenuItem clearJMenuItem;
    private javax.swing.JPanel controlJPanel;
    private javax.swing.JMenuItem deleteJMenuItem;
    private javax.swing.JMenuItem detailsJMenuItem;
    private javax.swing.JMenuItem editJMenuItem;
    private javax.swing.JMenuItem exitJMenuItem;
    private javax.swing.JMenu fileJMenu;
    private javax.swing.JPopupMenu.Separator fileJSeparator;
    private javax.swing.JMenu helpJMenu;
    private javax.swing.JLabel horseJLabel;
    private javax.swing.JComboBox horsesJComboBox;
    private javax.swing.JMenuBar horsesJMenuBar;
    private javax.swing.JMenuItem newJMenuItem;
    private javax.swing.JButton nextJButton;
    private javax.swing.JButton playJButton;
    private javax.swing.JMenuItem printDetailsJMenuItem;
    private javax.swing.JMenuItem printFormJMenuItem;
    private javax.swing.JLabel questionJLabel;
    private javax.swing.JTextField questionsJTextField;
    private javax.swing.JLabel quizJLabel;
    private javax.swing.JLabel resultJLabel;
    private javax.swing.JMenuItem searchJMenuItem;
    private javax.swing.JLabel selectJLabel;
    private javax.swing.JPanel selectJPanel;
    private javax.swing.JButton submitJButton;
    // End of variables declaration//GEN-END:variables



        
}